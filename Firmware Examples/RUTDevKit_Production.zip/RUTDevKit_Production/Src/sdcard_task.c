#include "main.h"
#include "cmsis_os.h"
#include "usbpd.h"
#include "sdcard_task.h"
#include "stdio.h" 
#include "string.h" 
#include "usbpd_trace.h"
#include "app_fatfs.h"
#include "stdlib.h"
#include "canfd_task.h"

extern osThreadId_t SDCardTaskHandle;
extern osThreadId_t CANFDTaskHandle;

const osThreadAttr_t canfdTask_attributes = 
{
  .name = "canfd_task",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 1024
};

void SDCardTask(void *argument)
{
  char buff[64];
  extern FATFS SDFatFS;    /* File system object for SD logical drive */
  extern char SDPath[4];   /* SD logical drive path */
  extern FIL SDFile;       /* File object for SD */
  FRESULT fs_result;
  char *buffer, *memory;

  /* Wait 1000ms */
  osDelay(1000);
    
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "SD Card Test Started");
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  
  /*Allocate memory buffer*/
  buffer = (char*)malloc(ALLOC_SIZE);
  if(buffer == NULL)
  {
    memset(buff, 0x00, sizeof(buff));
    sprintf(buff, "SDCard Memory Allocation FAILURE");
    USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
    goto exit_error;
  }
  
  /*Mount the media and write with a new test file*/
  fs_result = f_mount(&SDFatFS, SDPath, 1);
  if (fs_result == FR_OK)
  {
    fs_result = f_unlink("TEST.TXT");
    if ((fs_result == FR_NO_FILE) || (fs_result == FR_OK) )
    {
      fs_result = f_open(&SDFile, "TEST.TXT", FA_WRITE | FA_CREATE_ALWAYS);
      if (fs_result == FR_OK)
      {
        memset(buffer, 'A', ALLOC_SIZE);
        UINT bw;
        f_write(&SDFile, buffer, ALLOC_SIZE, &bw);
        f_close(&SDFile);
      }
     }
    else
    {
     memset(buff, 0x00, sizeof(buff));
     sprintf(buff, "SD Card File Write FAILURE");
     USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
     goto exit_error;
    }
  }
  else
  {
     memset(buff, 0x00, sizeof(buff));
     sprintf(buff, "SD Card Mount FAILURE");
     USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
     goto exit_error;
  }
  
  /*Open and read test file*/
  fs_result = f_open(&SDFile, "TEST.TXT", FA_READ);
  {
    if(fs_result == FR_OK)
    {
      UINT br = 0;
      memset(buffer, 0x00, ALLOC_SIZE);
      f_read(&SDFile, buffer, ALLOC_SIZE, &br);
      f_close(&SDFile);
      if((br==0) || (br<ALLOC_SIZE))
      {
        memset(buff, 0x00, sizeof(buff));
        sprintf(buff, "SD Card File Open FAILURE");
        USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
        goto exit_error;
      }
    }
    else
    {
      memset(buff, 0x00, sizeof(buff));
      sprintf(buff, "SD Card File Open FAILURE");
      USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
      goto exit_error;
    }
  }
  
  /*Check if the data in the memory is correct*/
  memory = buffer;
  for(uint32_t i = 0; i < ALLOC_SIZE; i++)
  {
    if(*memory != 'A')
    {
      memset(buff, 0x00, sizeof(buff));
      sprintf(buff, "SD Card Data Check Failure");
      USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
      goto exit_error;
    }
    memory++;
  }
  
  free(buffer);
  
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "SD Card Test PASS");
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  
  CANFDTaskHandle = osThreadNew(CANFDTask, NULL, &canfdTask_attributes);
  osThreadTerminate (SDCardTaskHandle);
  
  exit_error:
  CANFDTaskHandle = osThreadNew(CANFDTask, NULL, &canfdTask_attributes);
  osThreadTerminate (SDCardTaskHandle);
  while(1)
  {
    osDelay(1000);
  }
}