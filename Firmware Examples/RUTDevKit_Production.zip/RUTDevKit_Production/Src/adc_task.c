#include "main.h"
#include "cmsis_os.h"
#include "usbpd.h"
#include "adc_task.h"
#include "stdio.h"
#include "string.h" 
#include "usbpd_trace.h"
#include "app_fatfs.h"
#include "stdlib.h"
#include "led_task.h"

extern osThreadId_t ADCTaskHandle;
extern osThreadId_t LEDTaskHandle;
extern ADC_HandleTypeDef hadc1;

const osThreadAttr_t ledTask_attributes = 
{
  .name = "led_task",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 1024
};


static uint32_t poll_ADC_channel(uint32_t channel);

void ADCTask(void *argument)
{
  char buff[64];
  uint32_t value;
  
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "ADC Test Started");
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  
  osDelay(100);
  value = poll_ADC_channel(ADC_CHANNEL_1);
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "ADC INPUT 1 = %d mV", value);
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  
  osDelay(100);
  value = poll_ADC_channel(ADC_CHANNEL_2);
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "ADC INPUT 2 = %d mV", value);
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  
  osDelay(100);
  value = poll_ADC_channel(ADC_CHANNEL_3);
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "ADC INPUT 3 = %d mV", value);
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  
  osDelay(100);
  value = poll_ADC_channel(ADC_CHANNEL_5);
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "ADC INPUT 5 = %d mV", value);
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  
  osDelay(100);
  value = poll_ADC_channel(ADC_CHANNEL_7);
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "ADC INPUT 7 = %d mV", value);
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  
  LEDTaskHandle = osThreadNew(LEDTask, NULL, &ledTask_attributes);
  osThreadTerminate (ADCTaskHandle);

  /* Wait 1000ms */
  while(1)
  {
    osDelay(1000);
  }
}

static uint32_t poll_ADC_channel(uint32_t channel)
{
  ADC_ChannelConfTypeDef sConfig = {0};
  
  HAL_ADC_Stop(&hadc1);
  
  sConfig.Channel = channel;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_247CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);
  HAL_ADCEx_Calibration_Start(&hadc1,ADC_SINGLE_ENDED);
  
  HAL_ADC_Start(&hadc1);
  HAL_Delay(10);
  
  return __LL_ADC_CALC_DATA_TO_VOLTAGE(VDDA_APPLI,  LL_ADC_REG_ReadConversionData12(hadc1.Instance), LL_ADC_RESOLUTION_12B); /* mV */
}