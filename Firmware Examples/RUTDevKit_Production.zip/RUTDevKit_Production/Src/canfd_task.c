#include "main.h"
#include "cmsis_os.h"
#include "usbpd.h"
#include "canfd_task.h"
#include "stdio.h"
#include "string.h" 
#include "usbpd_trace.h"
#include "app_fatfs.h"
#include "stdlib.h"
#include "adc_task.h"

extern osThreadId_t CANFDTaskHandle;
extern FDCAN_HandleTypeDef hfdcan1;
extern osThreadId_t ADCTaskHandle;

const osThreadAttr_t adcTask_attributes = 
{
  .name = "adc_task",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 1024
};

FDCAN_TxHeaderTypeDef TxHeader;
FDCAN_RxHeaderTypeDef RxHeader;
FDCAN_FilterTypeDef RxFilter;
uint8_t RxData[16];
uint8_t TxData[] = {'H', 'E', 'L', 'L', 'O', ' ', 'W','O','R','L','D','\0'};

static uint32_t Compare(uint8_t* Data1, uint8_t* Data2, uint16_t Length);

void CANFDTask(void *argument)
{
  char buff[64];
  
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "CAN FD Test Started");
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  
  /* Wait 1000ms */
  osDelay(1000);
  
  /*CAN FD Setup*/
  HAL_GPIO_WritePin(CAN_STB_GPIO_Port, CAN_STB_Pin, GPIO_PIN_RESET);
  RxFilter.IdType = FDCAN_STANDARD_ID;
  RxFilter.FilterIndex = 0;
  RxFilter.FilterType = FDCAN_FILTER_MASK;
  RxFilter.FilterConfig = FDCAN_FILTER_TO_RXFIFO0;
  RxFilter.FilterID1 = 0x1;
  RxFilter.FilterID2 = 0x7FF;
  if(HAL_FDCAN_ConfigFilter(&hfdcan1, &RxFilter) != HAL_OK)
  {
    memset(buff, 0x00, sizeof(buff));
    sprintf(buff, "CAN FD Init FAILURE");
    USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
    goto exit_error;
  }
  if(HAL_FDCAN_ConfigGlobalFilter(&hfdcan1, FDCAN_REJECT, FDCAN_REJECT, FDCAN_REJECT_REMOTE, FDCAN_REJECT_REMOTE) != HAL_OK)
  {
    memset(buff, 0x00, sizeof(buff));
    sprintf(buff, "CAN FD Init FAILURE");
    USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
    goto exit_error;
  }
  if(HAL_FDCAN_Start(&hfdcan1) != HAL_OK)
  {
    memset(buff, 0x00, sizeof(buff));
    sprintf(buff, "CAN FD Init FAILURE");
    USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
    goto exit_error;
  }
  
  /*Test*/
  TxHeader.Identifier = 0x1;
  TxHeader.IdType = FDCAN_STANDARD_ID;
  TxHeader.TxFrameType = FDCAN_DATA_FRAME;
  TxHeader.DataLength = FDCAN_DLC_BYTES_16;
  TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;
  TxHeader.BitRateSwitch = FDCAN_BRS_ON;
  TxHeader.FDFormat = FDCAN_FD_CAN;
  TxHeader.TxEventFifoControl = FDCAN_NO_TX_EVENTS;
  TxHeader.MessageMarker = 0;
  HAL_FDCAN_AddMessageToTxFifoQ(&hfdcan1, &TxHeader, TxData);
  osDelay(100);
  while(HAL_FDCAN_GetRxFifoFillLevel(&hfdcan1, FDCAN_RX_FIFO0) < 1){}
  HAL_FDCAN_GetRxMessage(&hfdcan1, FDCAN_RX_FIFO0, &RxHeader, &RxData[0]);
  
  if(Compare(TxData, RxData, 16) != 0)
  {
    Error_Handler();
  }
  else
  {
    memset(buff, 0x00, sizeof(buff));
    sprintf(buff, "CAN FD Data Transreceived: %s", RxData);
    USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  }
  
  ADCTaskHandle = osThreadNew(ADCTask, NULL, &adcTask_attributes);
  osThreadTerminate (CANFDTaskHandle);
  
  exit_error:
  /* Wait 1000ms */
  while(1)
  {
    osDelay(1000);
  }
}

static uint32_t Compare(uint8_t* Data1, uint8_t* Data2, uint16_t Length)
{
  while(Length--)
  {
    if(*Data1 != *Data2)
    {
      return 1;
    }
    Data1++;
    Data2++;
  }
  return 0;
}