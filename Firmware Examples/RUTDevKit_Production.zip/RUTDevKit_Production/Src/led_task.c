#include "main.h"
#include "cmsis_os.h"
#include "usbpd.h"
#include "led_task.h"
#include "stdio.h"
#include "string.h" 
#include "usbpd_trace.h"
#include "app_fatfs.h"
#include "stdlib.h"
#include "button_task.h"

extern osThreadId_t LEDTaskHandle;
extern osThreadId_t ButtonTaskHandle;

const osThreadAttr_t buttonTask_attributes = 
{
  .name = "button_task",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 1024
};

void LEDTask(void *argument)
{
  char buff[64];
  
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "LED Test Started");
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "US1 LED Blinking...");
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  for(uint32_t i = 0; i < 100; i++)
  {
    HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET);
    osDelay(25);
    HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);
    osDelay(25);
  }
  
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "US2 LED Blinking...");
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  for(uint32_t i = 0; i < 100; i++)
  {
    HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);
    osDelay(25);
    HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);
    osDelay(25);
  }
  
  ButtonTaskHandle = osThreadNew(ButtonTask, NULL, &buttonTask_attributes);
  osThreadTerminate (LEDTaskHandle);
  
  /* Wait 1000ms */
  while(1)
  {
    osDelay(1000);
  }
}