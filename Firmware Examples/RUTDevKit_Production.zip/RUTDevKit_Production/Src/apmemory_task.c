#include "main.h"
#include "cmsis_os.h"
#include "usbpd.h"
#include "apmemory_task.h"
#include "stdio.h" 
#include "string.h" 
#include "usbpd_trace.h"
#include "sdcard_task.h"

extern osThreadId_t APMemoryTaskHandle;
extern osThreadId_t SDCardTaskHandle;

const osThreadAttr_t sdcardTask_attributes = 
{
  .name = "sdcard_task",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 1024
};

void APMemoryTask(void *argument)
{
  char buff[64];
  __IO uint8_t *mem_addr;
  uint32_t address = 0;
  uint32_t i,j = 0;

  /* Wait 1000ms */
  osDelay(1000);
    
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "PSRAM Test Started");
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  
  /*Clean*/
  for(i = 0; i < 8192; i++)
  {
    mem_addr = (uint8_t *)(OCTOSPI1_BASE + address);
    memset((void *)mem_addr, 0x00, 1024);
    address += 1024;
  }
  address = 0;
  
  /*Write*/
  for( i = 0; i < 8192; i++)
  {
    mem_addr = (uint8_t *)(OCTOSPI1_BASE + address);
    memset((void *)mem_addr, 0xAA, 1024);
    address += 1024;
  }
  address = 0;
  
  /*Read/Check*/
  for( i = 0; i < 8192; i++)
  {
    mem_addr = (uint8_t *)(OCTOSPI1_BASE + address);
    for(j = 0; j < 1024; j++)
    {
      if (*mem_addr != 0xAA)
      {
          memset(buff, 0x00, sizeof(buff));
          sprintf(buff, "PSRAM Test FAIL");
          USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
          goto exit_error;
      }
      mem_addr++;
    }
    address += 1024;
  }
  
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "PSRAM Test PASS");
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  
  address = 0;
  
  SDCardTaskHandle = osThreadNew(SDCardTask, NULL, &sdcardTask_attributes);
  osThreadTerminate (APMemoryTaskHandle);
  
exit_error:
  while (1)
  {
    osDelay(1000);
  }
}