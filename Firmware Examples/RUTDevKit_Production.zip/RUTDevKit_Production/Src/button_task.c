#include "main.h"
#include "cmsis_os.h"
#include "usbpd.h"
#include "stdio.h"
#include "string.h" 
#include "usbpd_trace.h"
#include "app_fatfs.h"
#include "stdlib.h"
#include "button_task.h"

extern osThreadId_t ButtonTaskHandle;
extern osSemaphoreId_t user1;
extern osSemaphoreId_t user2;

void ButtonTask(void *argument)
{
  char buff[64];
  
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "Buttons Test Started");
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));

  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "Press USER1 Button");
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET);
  if (osSemaphoreAcquire(user1, portMAX_DELAY) == osOK)
  {
    memset(buff, 0x00, sizeof(buff));
    sprintf(buff, "USER1 Button Pressed!");
    USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
    HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);
  }
  
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "Press USER2 Button");
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff)); 
  HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);
  if (osSemaphoreAcquire(user2, portMAX_DELAY) == osOK)
  {
    memset(buff, 0x00, sizeof(buff));
    sprintf(buff, "USER2 Button Pressed!");
    USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff)); 
    HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);
  }
  
  memset(buff, 0x00, sizeof(buff));
  sprintf(buff, "ALL TESTS PASSED");
  USBPD_TRACE_Add(USBPD_TRACE_DEBUG, 1u, 0u, (uint8_t*)buff, strlen(buff));
  osThreadTerminate (ButtonTaskHandle);
  
  /* Wait 1000ms */
  while(1)
  {
    osDelay(1000);
  }
}

void HAL_GPIO_EXTI_Falling_Callback(uint16_t GPIO_Pin)
{
  if(GPIO_Pin == GPIO_PIN_6)
  {
    osSemaphoreRelease(user1);
  }
  
  if(GPIO_Pin == GPIO_PIN_7)
  {
    osSemaphoreRelease(user2);
  }
}