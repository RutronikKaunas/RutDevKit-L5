/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l5xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "cmsis_os.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
extern osMutexId_t uart1_mutex;
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define MessageReady_Pin GPIO_PIN_6
#define MessageReady_GPIO_Port GPIOF
#define VSENSE_Pin GPIO_PIN_2
#define VSENSE_GPIO_Port GPIOA
#define TCPP01_DB_Pin GPIO_PIN_5
#define TCPP01_DB_GPIO_Port GPIOA
#define DeviceReset_Pin GPIO_PIN_8
#define DeviceReset_GPIO_Port GPIOE
#define ChipSelect_Pin GPIO_PIN_9
#define ChipSelect_GPIO_Port GPIOE
#define SPI_CS_Pin GPIO_PIN_5
#define SPI_CS_GPIO_Port GPIOG
#define uSD_DETECT_Pin GPIO_PIN_7
#define uSD_DETECT_GPIO_Port GPIOC
#define CAN_STB_Pin GPIO_PIN_8
#define CAN_STB_GPIO_Port GPIOA
#define Standbyexit_Pin GPIO_PIN_9
#define Standbyexit_GPIO_Port GPIOG
#define Mute_Pin GPIO_PIN_15
#define Mute_GPIO_Port GPIOG
#define BUTTON1_Pin GPIO_PIN_6
#define BUTTON1_GPIO_Port GPIOB
#define BUTTON1_EXTI_IRQn EXTI6_IRQn
#define BUTTON2_Pin GPIO_PIN_7
#define BUTTON2_GPIO_Port GPIOB
#define BUTTON2_EXTI_IRQn EXTI7_IRQn
#define LED1_Pin GPIO_PIN_8
#define LED1_GPIO_Port GPIOB
#define LED2_Pin GPIO_PIN_9
#define LED2_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */
#define true	1
#define false	0
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
