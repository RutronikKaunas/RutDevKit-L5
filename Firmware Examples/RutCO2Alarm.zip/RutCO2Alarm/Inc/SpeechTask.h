/*
 * SpeechTask.h
 *
 *  Created on: Aug 10, 2020
 *      Author: GDR
 */

#ifndef SPEECHTASK_H_
#define SPEECHTASK_H_

#include "main.h"
#include "cmsis_os.h"
#include "stdio.h"
#include "../RutEpsonDriver/spi_api.h"

typedef struct speech_sensor
{
	 uint8_t phrase_number;
}speech_t;

extern osThreadId SpeechTaskHandle;
extern osMessageQueueId_t speech_MsgQueue;
extern speech_t speech_msg;
extern const osThreadAttr_t SpeechTask_attributes;

void SpeechTask(void *argument);

#endif /* SPEECHTASK_H_ */
