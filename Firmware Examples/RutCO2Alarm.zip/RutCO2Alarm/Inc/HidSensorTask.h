/*
 * HidSensorTask.h
 *
 *  Created on: 2020-07-22
 *      Author: Gintaras Drukteinis
 */

#ifndef HIDSENSORTASK_H_
#define HIDSENSORTASK_H_

#include "main.h"
#include "cmsis_os.h"

typedef struct hid_sensor
{
	 uint8_t HID_Buffer[4];
}hid_sensor_t;

typedef struct sensor_message
{
	hid_sensor_t sensor_data;
} sensor_msg_t;

extern osThreadId HidSensorTaskHandle;
extern osMessageQueueId_t hid_MsgQueue;
extern sensor_msg_t sensor_msg;
extern hid_sensor_t hid_sensor_data;
extern const osThreadAttr_t HidSensorTask_attributes;

void HidSensorTask(void *argument);


#endif /* HIDSENSORTASK_H_ */
