/*
 * MainTask.c
 *
 *  Created on: Jul 22, 2020
 *      Author: Gintaras Drukteinis
 *		Author: Albert Golek
 *  Added SGP30 and S1V30340 Drivers 31.07.2020
 *  
 */

#include "MainTask.h"
#include "HidSensorTask.h"
#include "SpeechTask.h"
#include "stdio.h"
#include "../SGP30/Inc/sensirion_common.h"
#include "../SGP30/Inc/sgp30.h"
#include "../RutEpsonDriver/spi_api.h"
#include "../RutEpsonDriver/isc_msgs.h"

#define DEBUG_CO2_VALUE

osThreadId MainTaskHandle;
osTimerId phrase_repeat = NULL;
osTimerId speech_check = NULL;
extern I2C_HandleTypeDef hi2c1;
co2status_t co2_state_prev = CO2_UNDEFINED;
int co2_buff[10] = {0};
int buff_pos = 0;
long sum = 0;
_Bool check = true;

const osThreadAttr_t MainTask_attributes =
{
  .name = "MainTask",
  .priority = (osPriority_t) osPriorityNormal1,
  .stack_size = 1024
};

static void Phrase_Repeat_Callback(void *argument);
static void Speech_Check_Callback(void *argument);
static co2status_t DecodeCO2Level(int co2eq_ppm);
static int MovingAvg(int *ptrArrNumbers, long *ptrSum, int pos, int len, int nextNum);

void MainTask(void *argument)
{
	sensor_msg_t hid_msg;
	speech_t speech_msg;
	osStatus_t msg_status;
	co2status_t co2_state = CO2_UNDEFINED;
	uint16_t tvoc_ppb = 0;
	uint16_t co2_eq_ppm = 0;
	int co2_av = 0;
	int buff_len;
	int epson_init = -1;

#ifdef DEBUG_CO2_VALUE
	uint8_t cnt = 0;
#endif

	printf("Main task started. \n\r");

	/*Hard-Reset Procedure*/
	GPIO_S1V30340_Reset(1);
	osDelay(100);
	GPIO_S1V30340_Reset(0);
	osDelay(100);
	GPIO_S1V30340_Reset(1);
	osDelay(500);

	/*Set mute signal(MUTE) to High(disable)*/
	GPIO_ControlMute(0);

	/*Set standby signal(STBYEXIT) to Low(deassert)*/
	GPIO_ControlStandby(0);
	osDelay(100);

	/*Initialize Epson ASIC*/
	epson_init = S1V30340_Initialize_Audio_Config();
	while(epson_init != 0)
	{
		printf("S1V30340 SPI Initialization failed. \n\r");
		HAL_Delay(1000);
		epson_init = S1V30340_Initialize_Audio_Config();
	}
	printf("S1V30340 SPI Initialization succeeded. \n\r");

	/*Play the greeting*/
	GPIO_ControlMute(1); /*Mute - OFF*/
	S1V30340_Play_Specific_Audio(GREETING_PHRASE);
	S1V30340_Wait_For_Termination();
	GPIO_ControlMute(0); /*Mute - ON*/

	/*Initialize SGP30 sensor*/
	speech_msg.phrase_number = 0;
	while(sgp_probe() != STATUS_OK)
	{
		printf("SGP sensor probing failed ... check SGP30 I2C connection and power \n\r");
		HAL_Delay(1000);
	}
	printf("Sensor probing successful \r\n");
	sgp_iaq_init();

	for(;;)
	{
		/*Task executed 10 times per second*/
		osDelay(100);

		/*Do the measurement*/
	    if(!(sgp_measure_iaq_blocking_read(&tvoc_ppb, &co2_eq_ppm) == STATUS_OK))
	    {
	    	co2_eq_ppm = 0;
	    	tvoc_ppb = 0;
	    	printf("Could not read CO2 sensor values \r\n");
	    	osDelay(1000);
	    }

#ifdef DEBUG_CO2_VALUE
	    if(cnt == 9)
	    {
	    	cnt = 0;
	    	printf("CO2 equivalent value: %d ppm\r\n", co2_eq_ppm);
	    }
	    cnt++;
#endif

	    /*Do the moving average math*/
	    buff_len = sizeof(co2_buff)/sizeof(int);
	    co2_av = MovingAvg(co2_buff, &sum, buff_pos, buff_len, (int)co2_eq_ppm);
	    buff_pos++;
	    if(buff_pos >= buff_len){buff_pos = 0;}

	    /*Wrap averaged sensor value into the message*/
	    hid_msg.sensor_data.HID_Buffer[0] = (co2_av >> 24);
	    hid_msg.sensor_data.HID_Buffer[1] = (co2_av >> 16);
	    hid_msg.sensor_data.HID_Buffer[2] = (co2_av >> 8);
	    hid_msg.sensor_data.HID_Buffer[3] = (co2_av >> 0);

		/*Send the message to the USB HID Device*/
		msg_status = osMessageQueuePut (hid_MsgQueue, &hid_msg, 0, 1000);
		if(msg_status != osOK)
		{
			printf("Timeout: Could not send the HID sensor data.\n\r");
		}

		/*Speech engine periodic check*/
		if(check)
		{
			/*Self lock-out*/
			check = false;

			/*Check the current status of the CO2 concentration*/
			co2_state = DecodeCO2Level(co2_av);

			/*Play warning messages according to the CO2 concentration*/
			msg_status = osError;
			switch (co2_state)
			{
				case CO2_NORMAL:
				{
					/*Play the message only once on state change*/
					if(co2_state_prev != CO2_NORMAL)
					{
						speech_msg.phrase_number = CO2_NORMAL_PHRASE;
						msg_status = osMessageQueuePut (speech_MsgQueue, &speech_msg, 0, 0);
						if(msg_status == osOK)
						{
							if(phrase_repeat != NULL)
							{
								osTimerDelete (phrase_repeat);
								phrase_repeat = NULL;
							}

							co2_state_prev = CO2_NORMAL;
						}
					}
					break;
				}
				case CO2_MINIMUM:
				{
					/*Play the message only once on state change*/
					if(co2_state_prev != CO2_MINIMUM)
					{
						speech_msg.phrase_number = CO2_MINIMUM_PHRASE;
						msg_status = osMessageQueuePut (speech_MsgQueue, &speech_msg, 0, 0);
						if(msg_status == osOK)
						{
							if(phrase_repeat != NULL)
							{
								osTimerDelete (phrase_repeat);
								phrase_repeat = NULL;
							}

							co2_state_prev = CO2_MINIMUM;
						}
					}
					break;
				}
				case CO2_MEDIUM:
				{
					/*Play the message every xx seconds*/
					if(co2_state_prev != CO2_MEDIUM)
					{
						speech_msg.phrase_number = CO2_MEDIUM_PHRASE;
						msg_status = osMessageQueuePut (speech_MsgQueue, &speech_msg, 0, 0);
						if(msg_status == osOK)
						{
							if(phrase_repeat != NULL)
							{
								osTimerDelete (phrase_repeat);
								phrase_repeat = NULL;
							}

							co2_state_prev = CO2_MEDIUM;

							phrase_repeat = osTimerNew (Phrase_Repeat_Callback, osTimerOnce,(void *)0, NULL);
							osTimerStart (phrase_repeat, CO2_MEDIUM_REPEAT);
						}
					}
					break;
				}
				case CO2_MAXIMUM:
				{
					/*Play the message every xx seconds*/
					if(co2_state_prev != CO2_MAXIMUM)
					{
						speech_msg.phrase_number = CO2_MAXIMUM_PHRASE;
						msg_status = osMessageQueuePut (speech_MsgQueue, &speech_msg, 0, 0);
						if(msg_status == osOK)
						{
							if(phrase_repeat != NULL)
							{
								osTimerDelete (phrase_repeat);
								phrase_repeat = NULL;
							}

							co2_state_prev = CO2_MAXIMUM;

							phrase_repeat = osTimerNew (Phrase_Repeat_Callback, osTimerOnce,(void *)0, NULL);
							osTimerStart (phrase_repeat, CO2_MAXIMUM_REPEAT);
						}
					}
					break;
				}
				case CO2_EXTREME:
				{
					/*Play the message every xx seconds*/
					if(co2_state_prev != CO2_EXTREME)
					{
						speech_msg.phrase_number = CO2_EXTREME_PHRASE;
						msg_status = osMessageQueuePut (speech_MsgQueue, &speech_msg, 0, 0);
						if(msg_status == osOK)
						{
							if(phrase_repeat != NULL)
							{
								osTimerDelete (phrase_repeat);
								phrase_repeat = NULL;
							}

							co2_state_prev = CO2_EXTREME;

							phrase_repeat = osTimerNew (Phrase_Repeat_Callback, osTimerOnce,(void *)0, NULL);
							osTimerStart (phrase_repeat, CO2_EXTREME_REPEAT);
						}
					}
					break;
				}
				case CO2_UNDEFINED:
				{
					break;
				}
				default:
				{
					break;
				}
			}

			/*Start the timer which will activate next speech engine check*/
			speech_check = osTimerNew (Speech_Check_Callback, osTimerOnce,(void *)0, NULL);
			osTimerStart (speech_check, SPEECH_ENGINE_CHECK);
		}
	}
}

static co2status_t DecodeCO2Level(int co2eq_ppm)
{
	if(co2eq_ppm >= LVL_NORMAL && co2eq_ppm < LVL_MINIMUM)
	{
		return CO2_NORMAL;
	}
	else if (co2eq_ppm >= LVL_MINIMUM && co2eq_ppm < LVL_MEDIUM)
	{
		return CO2_MINIMUM;
	}
	else if (co2eq_ppm >= LVL_MEDIUM && co2eq_ppm < LVL_MAXIMUM)
	{
		return CO2_MEDIUM;
	}
	else if (co2eq_ppm >= LVL_MAXIMUM && co2eq_ppm < LVL_EXTREME)
	{
		return CO2_MAXIMUM;
	}
	else if (co2eq_ppm >= LVL_EXTREME)
	{
		return CO2_EXTREME;
	}
	else

	return CO2_UNDEFINED;
}

static int MovingAvg(int *ptrArrNumbers, long *ptrSum, int pos, int len, int nextNum)
{
  /*Subtract the oldest number from the previous sum, add the new number*/
  *ptrSum = *ptrSum - ptrArrNumbers[pos] + nextNum;

  /*Assign the nextNum to the position in the array*/
  ptrArrNumbers[pos] = nextNum;

  /*Return the average*/
  return *ptrSum / len;
}

void Phrase_Repeat_Callback(void *argument)
{
	osTimerDelete(phrase_repeat);
	phrase_repeat = NULL;
	co2_state_prev = CO2_UNDEFINED;
}

void Speech_Check_Callback(void *argument)
{
	osTimerDelete(speech_check);
	speech_check = NULL;
	check = true;
}
