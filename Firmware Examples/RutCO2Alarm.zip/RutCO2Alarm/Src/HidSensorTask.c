/*
 * HidSensorTask.c
 *
 *  Created on: 2020-07-22
 *      Author: Gintaras Drukteinis
 */

#include "HidSensorTask.h"
#include "usb_device.h"
#include "usbd_hid.h"
#include "main.h"
#include "stdio.h"

osThreadId HidSensorTaskHandle;
osMessageQueueId_t hid_MsgQueue;
sensor_msg_t sensor_msg;
extern USBD_HandleTypeDef hUsbDeviceFS;

const osThreadAttr_t HidSensorTask_attributes =
{
  .name = "HidSenTask",
  .priority = (osPriority_t) osPriorityAboveNormal,
  .stack_size = 512
};

hid_sensor_t hid_sensor_data =
{
		.HID_Buffer[0] = 0x00,
		.HID_Buffer[1] = 0x00,
		.HID_Buffer[2] = 0x00,
		.HID_Buffer[3] = 0x00,
};

void HidSensorTask(void *argument)
{
	sensor_msg_t msg;
	osStatus_t msg_status;

	printf("HID Sensor task started. \n\r");

	for(;;)
	{
		msg_status = osMessageQueueGet(hid_MsgQueue, &msg, NULL, osWaitForever);
		if (msg_status == osOK)
		{
			if(hUsbDeviceFS.dev_state == USBD_STATE_CONFIGURED)
			{
				(void) USBD_HID_SendReport(&hUsbDeviceFS, msg.sensor_data.HID_Buffer, sizeof(msg.sensor_data.HID_Buffer));
				HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
			}
			else{HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);}
		}
	}
}
