/*
 * SpeechTask.c
 *
 *  Created on: Aug 10, 2020
 *      Author: GDR
 */

#include "SpeechTask.h"

osThreadId SpeechTaskHandle;
osMessageQueueId_t speech_MsgQueue;
speech_t speech_msg;

const osThreadAttr_t SpeechTask_attributes =
{
  .name = "SpeechTask",
  .priority = (osPriority_t) osPriorityNormal2,
  .stack_size = 512
};

void SpeechTask(void *argument)
{
	speech_t msg;
	osStatus_t msg_status;

	printf("Speech task started. \n\r");

	for(;;)
	{
		msg_status = osMessageQueueGet(speech_MsgQueue, &msg, NULL, osWaitForever);
		if (msg_status == osOK)
		{
			/*Play the track...*/
			GPIO_ControlMute(1); /*Mute - OFF*/
			S1V30340_Play_Specific_Audio(msg.phrase_number);
			S1V30340_Wait_For_Termination();
			GPIO_ControlMute(0); /*Mute - ON*/
		}
	}
}
