/////////////////////////////////////////////////////////////////////////////////
// File Name: reg.h
//
// Description: Register definition for S1C33E07
//
// Author: SEIKO EPSON
//
// History: 2008/02/15 1st. design
//
// Copyright(c) SEIKO EPSON CORPORATION 2007-2008, All rights reserved.
//
// $Id: reg.h,v 1.1.1.1 2008/08/28 07:12:47 bish2310 Exp $
/////////////////////////////////////////////////////////////////////////////////

/*****************************************************************************
	ITC 	(0x300260)	  I/O Port Controller
*****************************************************************************/

// Port input 0-1 interrupt priority register
#define ITC_INT_PP01L_ADDR	   ((volatile unsigned char*)0x00300260)
#define   ITC_INT_PP01L_PP0L   0x07 	  // [2:0] Port input 0 interrupt level
										  // [3]   reserved
#define   ITC_INT_PP01L_PP1L   0x70 	  // [6:4] Port input 1 interrupt level
										  // [7]   reserved

// Port input 2-3 interrupt priority register
#define ITC_INT_PP23L_ADDR	   ((volatile unsigned char*)0x00300261)
#define   ITC_INT_PP23L_PP2L   0x07 	  // [2:0] Port input 2 interrupt level
										  // [3]   reserved
#define   ITC_INT_PP23L_PP3L   0x70 	  // [6:4] Port input 3 interrupt level
										  // [7]   reserved

// Key input 0-1 interrupt priority register
#define ITC_INT_PK01L_ADDR	   ((volatile unsigned char*)0x00300262)
#define   ITC_INT_PK01L_PK0L   0x07 	  // [2:0] Key input 0 interrupt level
										  // [3]   reserved
#define   ITC_INT_PK01L_PP1L   0x70 	  // [6:4] Key input 1 interrupt level
										  // [7]   reserved

// HSDMA Ch.0-1 interrupt priority register
#define ITC_INT_PHSD01L_ADDR   ((volatile unsigned char*)0x00300263)
#define   ITC_INT_PHSD01L_PHSD0L 0x07		// [2:0] HSDMA Ch.0 interrupt level
										  // [3]   reserved
#define   ITC_INT_PHSD01L_PHSD1L 0x70		// [6:4] HSDMA Ch.1 interrupt level
										  // [7]   reserved

// HSDMA Ch.2-3 interrupt priority register
#define ITC_INT_PHSD23L_ADDR   ((volatile unsigned char*)0x00300264)
#define   ITC_INT_PHSD23L_PHSD2L 0x07		// [2:0] HSDMA Ch.2 interrupt level
										  // [3]   reserved
#define   ITC_INT_PHSD23L_PHSD3L 0x70		// [6:4] HSDMA Ch.3 interrupt level
										  // [7]   reserved

// IDMA interrupt priority register
#define ITC_INT_PDM_ADDR	   ((volatile unsigned char*)0x00300265)
#define   ITC_INT_PDM_PDM	   0x07 	  // [2:0] IDMA interrupt level
										  // [7:3] reserved

// 16-bit timer 0-1 interrupt priority register
#define ITC_INT_P16T01_ADDR    ((volatile unsigned char*)0x00300266)
#define   ITC_INT_P16T01_P16T0 0x07 	  // [2:0] 16-bit timer 0 interrupt level
										  // [3]   reserved
#define   ITC_INT_P16T01_P16T1 0x70 	  // [6:4] 16-bit timer 1 interrupt level
										  // [7]   reserved

// 16-bit timer 2-3 interrupt priority register
#define ITC_INT_P16T23_ADDR    ((volatile unsigned char*)0x00300267)
#define   ITC_INT_P16T23_P16T2 0x07 	  // [2:0] 16-bit timer 2 interrupt level
										  // [3]   reserved
#define   ITC_INT_P16T23_P16T3 0x70 	  // [6:4] 16-bit timer 3 interrupt level
										  // [7]   reserved

// 16-bit timer 4-5 interrupt priority register
#define ITC_INT_T16T45_ADDR    ((volatile unsigned char*)0x00300268)
#define   ITC_INT_T16T45_P16T4 0x07 	  // [2:0] 16-bit timer 4 interrupt level
										  // [3]   reserved
#define   ITC_INT_T16T45_P16T5 0x70 	  // [6:4] 16-bit timer 5 interrupt level
										  // [7]   reserved

// Port input 4-5 interrupt priority register
#define ITC_INT_PP45L_ADDR	   ((volatile unsigned char*)0x0030026C)
#define   ITC_INT_PP04L_PP0L   0x07 	  // [2:0] Port input 4 interrupt level
										  // [3]   reserved
#define   ITC_INT_PP05L_PP1L   0x70 	  // [6:4] Port input 5 interrupt level
										  // [7]   reserved

// Port input 6-7 interrupt priority register
#define ITC_INT_PP67L_ADDR	   ((volatile unsigned char*)0x0030026D)
#define   ITC_INT_PP06L_PP0L   0x07 	  // [2:0] Port input 6 interrupt level
										  // [3]   reserved
#define   ITC_INT_PP07L_PP1L   0x70 	  // [6:4] Port input 7 interrupt level
										  // [7]   reserved

// Serial I/F Ch.2, SPI interrupt priority register
#define ITC_INT_PSIO2_PSPI_ADDR   ((volatile unsigned char*)0x0030026e)
#define   ITC_INT_PSIO2_PSPI_PSIO2 0x07 	  // [2:0] Serial interface Ch.2 interrupt level
										  // [3]   reserved
#define   ITC_INT_PSIO2_PSPI_PSPI 0x70		 // [6:4] SPI interrupt level
										  // [7]   reserved

// Key input, Port input 0-3 interrupt enable register
#define ITC_INT_EK01_EP03_ADDR	   ((volatile unsigned char*)0x00300270)
#define   ITC_INT_EK01_EP03_EP0    0x01 	  // [0]   Port input 0
#define   ITC_INT_EK01_EP03_EP1    0x02 	  // [1]   Port input 1
#define   ITC_INT_EK01_EP03_EP2    0x04 	  // [2]   Port input 2
#define   ITC_INT_EK01_EP03_EP3    0x08 	  // [3]   Port input 3
#define   ITC_INT_EK01_EP03_EK0    0x10 	  // [4]   Key input 0
#define   ITC_INT_EK01_EP03_EK1    0x20 	  // [5]   Key input 1
                                        	  //  Reserved

// DMA interrupt enable register
#define ITC_INT_EDMA_ADDR	   ((volatile unsigned char*)0x00300271)
#define   ITC_INT_EDMA_EHDM0   0x01 	  // [0]   HSDMA Ch.0
#define   ITC_INT_EDMA_EHDM1   0x02 	  // [1]   HSDMA Ch.1
#define   ITC_INT_EDMA_EHDM2   0x04 	  // [2]   HSDMA Ch.2
#define   ITC_INT_EDMA_EHDM3   0x08 	  // [3]   HSDMA Ch.3
#define   ITC_INT_EDMA_EIDMA   0x10 	  // [4]   IDMA
										  // [7:5] reserved

// Port input 4-7, RTC, A/D interrupt enable register
#define ITC_INT_EP47_ERTC_EAD_ADDR	   ((volatile unsigned char*)0x00300277)
#define   ITC_INT_EP47_ERTC_EAD_EADC    0x01 	  // [0]   A/D out of range
#define   ITC_INT_EP47_ERTC_EAD_EADE    0x02 	  // [1]   A/D conversion completion
#define   ITC_INT_EP47_ERTC_EAD_ERTC    0x04 	  // [2]   RTC
#define   ITC_INT_EP47_ERTC_EAD_EP4     0x08 	  // [3]   Port input 4
#define   ITC_INT_EP47_ERTC_EAD_EP5     0x10 	  // [4]   Port input 5
#define   ITC_INT_EP47_ERTC_EAD_EP6     0x20 	  // [5]   Port input 6
#define   ITC_INT_EP47_ERTC_EAD_EP7     0x40 	  // [6]   Port input 7
                                             	  // [7]   Reserved


// Serial I/F Ch.2, SPI interrupt enable register
#define ITC_INT_ESIF2_ESPI_ADDR   ((volatile unsigned char*)0x00300279)
#define   ITC_INT_ESIF2_ESPI_ESERR2 0x01	   // [0]	SIF Ch.2 receive error
#define   ITC_INT_ESIF2_ESPI_ESRX2 0x02 	  // [1]   SIF Ch.2 receive buffer full
#define   ITC_INT_ESIF2_ESPI_ESTX2 0x04 	  // [2]   SIF Ch.2 transmit buffer empty
										  // [3]   reserved
#define   ITC_INT_ESIF2_ESPI_ESPIRX 0x10	   // [4]	SPI receive DMA
#define   ITC_INT_ESIF2_ESPI_ESPITX 0x20	   // [5]	SPI transmit DMA
										  // [7:6] reserved

// Key input, Port input 0-3 interrupt cause flag register
#define ITC_INT_FK01_FP03_ADDR	   ((volatile unsigned char*)0x00300280)
#define   ITC_INT_FK01_FP03_FP0    0x01 	  // [0]   Port input 0
#define   ITC_INT_FK01_FP03_FP1    0x02 	  // [1]   Port input 1
#define   ITC_INT_FK01_FP03_FP2    0x04 	  // [2]   Port input 2
#define   ITC_INT_FK01_FP03_FP3    0x08 	  // [3]   Port input 3
#define   ITC_INT_FK01_FP03_FK0    0x10 	  // [4]   Port input 0
#define   ITC_INT_FK01_FP03_FK1    0x20 	  // [5]   Port input 1
                                        	  // Reserved


// DMA interrupt cause flag register
#define ITC_INT_FDMA_ADDR	   ((volatile unsigned char*)0x00300281)
#define   ITC_INT_FDMA_FHDM0   0x01 	  // [0]   HSDMA Ch.0
#define   ITC_INT_FDMA_FHDM1   0x02 	  // [1]   HSDMA Ch.1
#define   ITC_INT_FDMA_FHDM2   0x04 	  // [2]   HSDMA Ch.2
#define   ITC_INT_FDMA_FHDM3   0x08 	  // [3]   HSDMA Ch.3
#define   ITC_INT_FDMA_FHDM4   0x10 	  // [4]   IDMA
										  // [7:5] reserved

// Port input 4-7, RTC A/D  interrupt cause flag register
#define ITC_INT_FP47_FRTC_FAD_ADDR	   ((volatile unsigned char*)0x00300287)
#define   ITC_INT_FP47_FRTC_FAD_FADC    0x01 	  // [0]   A/D out of range
#define   ITC_INT_FP47_FRTC_FAD_FADE    0x02 	  // [1]   A/D conversion completion
#define   ITC_INT_FP47_FRTC_FAD_FRTC    0x04 	  // [2]   RTC
#define   ITC_INT_FP47_FRTC_FAD_FP4     0x08 	  // [3]   Port input 4
#define   ITC_INT_FP47_FRTC_FAD_FP5     0x10 	  // [4]   Port input 5
#define   ITC_INT_FP47_FRTC_FAD_FP6     0x20 	  // [5]   Port input 6
#define   ITC_INT_FP47_FRTC_FAD_FP7     0x40 	  // [5]   Port input 7
                                             	  // Reserved

// Serial I/F Ch.2, SPI interrupt cause flag register
#define ITC_INT_FSIF2_FSPI_ADDR   ((volatile unsigned char*)0x00300289)
#define   ITC_INT_FSIF2_FSPI_FSERR2 0x01	   // [0]	SIF Ch.2 receive error
#define   ITC_INT_FSIF2_FSPI_FSRX2 0x02 	  // [1]   SIF Ch.2 receive buffer full
#define   ITC_INT_FSIF2_FSPI_FSTX2 0x04 	  // [2]   SIF Ch.2 transmit buffer empty
										  // [3]   reserved
#define   ITC_INT_FSIF2_FSPI_FSPIRX 0x10	   // [4]	SPI receive DMA
#define   ITC_INT_FSIF2_FSPI_FSPITX 0x20	   // [5]	SPI transmit DMA
										  // [7:6] reserved

// Port input 0-3, HSDMA Ch.0-1, 16-bit timer 0 IDMA request register
#define ITC_IDMAREQ_RP03_RHS_R16T0_ADDR   ((volatile unsigned char*)0x00300290)
#define   ITC_IDMAREQ_RP03_RHS_R16T0_RP0 0x01		// [0]	 Port input 0
#define   ITC_IDMAREQ_RP03_RHS_R16T0_RP1 0x02		// [1]	 Port input 1
#define   ITC_IDMAREQ_RP03_RHS_R16T0_RP2 0x04		// [2]	 Port input 2
#define   ITC_IDMAREQ_RP03_RHS_R16T0_RP3 0x08		// [3]	 Port input 3
#define   ITC_IDMAREQ_RP03_RHS_R16T0_RHDM0 0x10 	// [4]   HSDMA Ch.0
#define   ITC_IDMAREQ_RP03_RHS_R16T0_RHDM1 0x20 	// [5]   HSDMA Ch.1
#define   ITC_IDMAREQ_RP03_RHS_R16T0_R16TU0 0x40	// [6]	16-bit timer 0 comparison B
#define   ITC_IDMAREQ_RP03_RHS_R16T0_R16TC0 0x80	// [7]	16-bit timer 0 comparison A

// 16-bit timer 1-4 IDMA request register
#define ITC_IDMAREQ_R16T14_ADDR   ((volatile unsigned char*)0x00300291)
#define   ITC_IDMAREQ_R16T14_R16TU1 0x01			// [0]	 16-bit timer 1 comparison B
#define   ITC_IDMAREQ_R16T14_R16TC1 0x02			// [1]	 16-bit timer 1 comparison A
#define   ITC_IDMAREQ_R16T14_R16TU2 0x04			// [2]	 16-bit timer 2 comparison B
#define   ITC_IDMAREQ_R16T14_R16TC2 0x08			// [3]	 16-bit timer 2 comparison A
#define   ITC_IDMAREQ_R16T14_R16TU3 0x10			// [4]	 16-bit timer 3 comparison B
#define   ITC_IDMAREQ_R16T14_R16TC3 0x20			// [5]	 16-bit timer 3 comparison A
#define   ITC_IDMAREQ_R16T14_R16TU4 0x40			// [6]	 16-bit timer 4 comparison B
#define   ITC_IDMAREQ_R16T14_R16TC4 0x80			// [7]	 16-bit timer 4 comparison A

// 16-bit timer 5 IDMA request register
#define ITC_IDMAREQ_R16T5_RSIF0_ADDR   ((volatile unsigned char*)0x00300292)
#define   ITC_IDMAREQ_R16T5_RSIF0_R16TU5 0x01		// [0]	 16-bit timer 5 comparison B
#define   ITC_IDMAREQ_R16T5_RSIF0_R16TC5 0x02		// [1]	 16-bit timer 5 comparison A

// Port input 0-3, HSDMA Ch.0-1, 16-bit timer 0 IDMA enable register
#define ITC_IDMAEN_DEP03_DEHS_DE16T0_ADDR	((volatile unsigned char*)0x00300294)
#define   ITC_IDMAEN_DEP03_DEHS_DE16T0_DEP0 0x01		// [0]	Port input 0
#define   ITC_IDMAEN_DEP03_DEHS_DE16T0_DEP1 0x02		// [1]	Port input 1
#define   ITC_IDMAEN_DEP03_DEHS_DE16T0_DEP2 0x04		// [2]	Port input 2
#define   ITC_IDMAEN_DEP03_DEHS_DE16T0_DEP3 0x08		// [3]	Port input 3
#define   ITC_IDMAEN_DEP03_DEHS_DE16T0_DEHDM0 0x10		// [4]   HSDMA Ch.0
#define   ITC_IDMAEN_DEP03_DEHS_DE16T0_DEHDM1 0x20		// [5]   HSDMA Ch.1
#define   ITC_IDMAEN_DEP03_DEHS_DE16T0_DE16TU0 0x40 	// [6]   16-bit timer 0 comparison B
#define   ITC_IDMAEN_DEP03_DEHS_DE16T0_DE16TC0 0x80 	// [7]   16-bit timer 0 comparison A

// 16-bit timer 1-4 IDMA enable register
#define ITC_IDMAEN_DE16T14_ADDR   ((volatile unsigned char*)0x00300295)
#define   ITC_IDMAEN_DE16T14_DE16TU1 0x01			// [0]	 16-bit timer 1 comparison B
#define   ITC_IDMAEN_DE16T14_DE16TC1 0x02			// [1]	 16-bit timer 1 comparison A
#define   ITC_IDMAEN_DE16T14_DE16TU2 0x04			// [2]	 16-bit timer 2 comparison B
#define   ITC_IDMAEN_DE16T14_DE16TC2 0x08			// [3]	 16-bit timer 2 comparison A
#define   ITC_IDMAEN_DE16T14_DE16TU3 0x10			// [4]	 16-bit timer 3 comparison B
#define   ITC_IDMAEN_DE16T14_DE16TC3 0x20			// [5]	 16-bit timer 3 comparison A
#define   ITC_IDMAEN_DE16T14_DE16TU4 0x40			// [6]	 16-bit timer 4 comparison B
#define   ITC_IDMAEN_DE16T14_DE16TC4 0x80			// [7]	 16-bit timer 4 comparison A

// 16-bit timer 5 IDMA enable register
#define ITC_IDMAEN_DE16T5_DESIF0_ADDR   ((volatile unsigned char*)0x00300296)
#define   ITC_IDMAEN_DE16T5_DESIF0_DE16TU5 0x01		// [0]	 16-bit timer 5 comparison B
#define   ITC_IDMAEN_DE16T5_DESIF0_DE16TC5 0x02		// [1]	 16-bit timer 5 comparison A

// HSDMA Ch.0-1 trigger set-up register
#define ITC_HSDMA_HTGR1_ADDR   ((volatile unsigned char*)0x00300298)
#define   ITC_HSDMA_HTGR1_HSD0S 0x0f	   // [3:0] HSDMA Ch.0 trigger set-up
#define   ITC_HSDMA_HTGR1_HSD1S 0xf0	   // [7:4] HSDMA Ch.1 trigger set-up

// HSDMA Ch.2-3 trigger set-up register
#define ITC_HSDMA_HTGR2_ADDR   ((volatile unsigned char*)0x00300299)
#define   ITC_HSDMA_HTGR2_HSD2S 0x0f	   // [3:0] HSDMA Ch.2 trigger set-up
#define   ITC_HSDMA_HTGR2_HSD3S 0xf0	   // [7:4] HSDMA Ch.3 trigger set-up

// HSDMA software trigger register
#define ITC_HSDMA_HSOFTTGR_ADDR   ((volatile unsigned char*)0x0030029a)
#define   ITC_HSDMA_HSOFTTGR_HST0 0x01		 // [0]   HSDMA Ch.0 software trigger
#define   ITC_HSDMA_HSOFTTGR_HST1 0x02		 // [1]   HSDMA Ch.1 software trigger
#define   ITC_HSDMA_HSOFTTGR_HST2 0x04		 // [2]   HSDMA Ch.2 software trigger
#define   ITC_HSDMA_HSOFTTGR_HST3 0x08		 // [3]   HSDMA Ch.3 software trigger
										  // [7:4] reserved

// LCDC, serial I/F Ch.2, SPI IDMA request register
#define ITC_IDMAREQ_RLCDC_RSIF2_RSPI_ADDR	((volatile unsigned char*)0x00030029)
										  // [0]   reserved
#define   ITC_IDMAREQ_RLCDC_RSIF2_RSPI_RLCDC 0x02		// [1]	 LCDC frame end
#define   ITC_IDMAREQ_RLCDC_RSIF2_RSPI_RSRX2 0x04		// [2]	 SIF Ch.2 receive buffer full
#define   ITC_IDMAREQ_RLCDC_RSIF2_RSPI_RSTX2 0x08		// [3]	 SIF Ch.2 transmit buffer empty
#define   ITC_IDMAREQ_RLCDC_RSIF2_RSPI_RSPIRX 0x10		 // [4]   SPI receive DMA
#define   ITC_IDMAREQ_RLCDC_RSIF2_RSPI_RSPITX 0x20		 // [5]   SPI transmit DMA
										  // [7:6] reserved

// LCDC, serial I/F Ch.2, SPI IDMA enable register
#define ITC_IDMAEN_RLCDC_RSIF2_RSPI_ADDR   ((volatile unsigned char*)0x00030029)
										  // [0]   reserved
#define   ITC_IDMAEN_RLCDC_RSIF2_RSPI_DELCDC 0x02		// [1]	 LCDC frame end
#define   ITC_IDMAEN_RLCDC_RSIF2_RSPI_DESRX2 0x04		// [2]	 SIF Ch.2 receive buffer full
#define   ITC_IDMAEN_RLCDC_RSIF2_RSPI_DESTX2 0x08		// [3]	 SIF Ch.2 transmit buffer empty
#define   ITC_IDMAEN_RLCDC_RSIF2_RSPI_DESPIRX 0x10		 // [4]   SPI receive DMA
#define   ITC_IDMAEN_RLCDC_RSIF2_RSPI_DESPITX 0x20		 // [5]   SPI transmit DMA
										  // [7:6] reserved

// Port input 8-9 interrupt priority register
#define ITC_INT_PP89L_ADDR	   ((volatile unsigned char*)0x003002a0)
#define   ITC_INT_PP89L_PP8L   0x07 	  // [2:0] Port input 8/SPI interrupt level
										  // [3]   reserved
#define   ITC_INT_PP89L_PP9L   0x70 	  // [6:4] Port input 9/USB PDREQ interrupt level
										  // [7]   reserved

// Port input 10-11 interrupt priority register
#define ITC_INT_PP1011L_ADDR   ((volatile unsigned char*)0x003002a1)
#define   ITC_INT_PP1011L_PP10L 0x07	   // [2:0] Port input 10/USB interrupt level
										  // [3]   reserved
#define   ITC_INT_PP1011L_PP11L 0x70	   // [6:4] Port input 11/DCSIO interrupt level
										  // [7]   reserved

// Port input 12-13 interrupt priority register
#define ITC_INT_PP1213L_ADDR   ((volatile unsigned char*)0x003002a2)
#define   ITC_INT_PP1213L_PP12L 0x07	   // [2:0] Port input 12 interrupt level
										  // [3]   reserved
#define   ITC_INT_PP1213L_PP13L 0x70	   // [6:4] Port input 13 interrupt level
										  // [7]   reserved

// Port input 14-15 interrupt priority register
#define ITC_INT_PP1415L_ADDR   ((volatile unsigned char*)0x003002a3)
#define   ITC_INT_PP1415L_PP14L 0x07	   // [2:0] Port input 14 interrupt level
										  // [3]   reserved
#define   ITC_INT_PP1415L_PP15L 0x70	   // [6:4] Port input 15 interrupt level
										  // [7]   reserved

// I2S interrupt priority register
#define ITC_INT_PI2S_ADDR	   ((volatile unsigned char*)0x003002a4)
#define   ITC_INT_PI2S_PI2S    0x07 	  // [2:0] I2S interrupt level
										  // [7:3] reserved

// Port input 8-15 interrupt enable register
#define ITC_INT_EP815_ADDR	   ((volatile unsigned char*)0x003002a6)
#define   ITC_INT_EP815_EP8    0x01 	  // [0]   Port input 8/SPI
#define   ITC_INT_EP815_EP9    0x02 	  // [1]   Port input 9/USB PDREQ
#define   ITC_INT_EP815_EP10   0x04 	  // [2]   Port input 10/USB
#define   ITC_INT_EP815_EP11   0x08 	  // [3]   Port input 11/DCSIO
#define   ITC_INT_EP815_EP12   0x10 	  // [4]   Port input 12
#define   ITC_INT_EP815_EP13   0x20 	  // [5]   Port input 13
#define   ITC_INT_EP815_EP14   0x40 	  // [6]   Port input 14
#define   ITC_INT_EP815_EP15   0x80 	  // [7]   Port input 15

// I2S interrupt enable register
#define ITC_INT_EI2S_ADDR	   ((volatile unsigned char*)0x003002a7)
										  // [1:0] reserved
#define   ITC_INT_EI2S_EI2S    0x04 	  // [2]   I2S
										  // [7:3] reserved

// Port input 8-15 interrupt cause flag register
#define ITC_INT_FP815_ADDR	   ((volatile unsigned char*)0x003002a9)
#define   ITC_INT_FP815_FP8    0x01 	  // [0]   Port input 8/SPI
#define   ITC_INT_FP815_FP9    0x02 	  // [1]   Port input 9/USB PDREQ
#define   ITC_INT_FP815_FP10   0x04 	  // [2]   Port input 10/USB
#define   ITC_INT_FP815_FP11   0x08 	  // [3]   Port input 11/DCSIO
#define   ITC_INT_FP815_FP12   0x10 	  // [4]   Port input 12
#define   ITC_INT_FP815_FP13   0x20 	  // [5]   Port input 13
#define   ITC_INT_FP815_FP14   0x40 	  // [6]   Port input 14
#define   ITC_INT_FP815_FP15   0x80 	  // [7]   Port input 15

// I2S interrupt cause flag register
#define ITC_INT_FI2S_ADDR	   ((volatile unsigned char*)0x003002aa)
										  // [1:0] reserved
#define   ITC_INT_FI2S_FI2S    0x04 	  // [2]   I2S
										  // [7:3] reserved

// Port input 8-15 IDMA request register
#define ITC_IDMAREQ_RP815_ADDR	 ((volatile unsigned char*)0x003002ac)
#define   ITC_IDMAREQ_RP815_RP8 0x01	   // [0]	Port input 8/SPI
#define   ITC_IDMAREQ_RP815_RP9 0x02	   // [1]	Port input 9/USB PDREQ
#define   ITC_IDMAREQ_RP815_RP10 0x04		// [2]	 Port input 10/USB
#define   ITC_IDMAREQ_RP815_RP11 0x08		// [3]	 Port input 11/DCSIO
#define   ITC_IDMAREQ_RP815_RP12 0x10		// [4]	 Port input 12
#define   ITC_IDMAREQ_RP815_RP13 0x20		// [5]	 Port input 13
#define   ITC_IDMAREQ_RP815_RP14 0x40		// [6]	 Port input 14
#define   ITC_IDMAREQ_RP815_RP15 0x80		// [7]	 Port input 15

// I2S IDMA request register
#define ITC_IDMAREQ_RI2S_ADDR	((volatile unsigned char*)0x003002ad)
										  // [1:0] reserved
#define   ITC_IDMAREQ_RI2S_RI2S 0x04	   // [2]	I2S
										  // [7:3] reserved

// Port input 8-15 IDMA enable register
#define ITC_IDMAEN_DEP815_ADDR	 ((volatile unsigned char*)0x003002ae)
#define   ITC_IDMAEN_DEP815_DEP8 0x01		// [0]	 Port input 8/SPI
#define   ITC_IDMAEN_DEP815_DEP9 0x02		// [1]	 Port input 9/USB PDREQ
#define   ITC_IDMAEN_DEP815_DEP10 0x04		 // [2]   Port input 10/USB
#define   ITC_IDMAEN_DEP815_DEP11 0x08		 // [3]   Port input 11/DCSIO
#define   ITC_IDMAEN_DEP815_DEP12 0x10		 // [4]   Port input 12
#define   ITC_IDMAEN_DEP815_DEP13 0x20		 // [5]   Port input 13
#define   ITC_IDMAEN_DEP815_DEP14 0x40		 // [6]   Port input 14
#define   ITC_IDMAEN_DEP815_DEP15 0x80		 // [7]   Port input 15

// I2S IDMA enable register
#define ITC_IDMAEN_DEI2S_ADDR	((volatile unsigned char*)0x003002af)
										  // [1:0] reserved
#define   ITC_IDMAEN_DEI2S_DEI2S 0x04		// [2]	 I2S
										  // [7:3] reserved

/*****************************************************************************
	GPIO	(0x300380)	  I/O Port Controller
*****************************************************************************/

// P0 port data register
#define GPIO_P0_P0D_ADDR	   ((volatile unsigned char*)0x00300380)
#define   GPIO_P0_P0D_P00D	   0x01 	  // [0]   P00 I/O port data
#define   GPIO_P0_P0D_P01D	   0x02 	  // [1]   P01 I/O port data
#define   GPIO_P0_P0D_P02D	   0x04 	  // [2]   P02 I/O port data
#define   GPIO_P0_P0D_P03D	   0x08 	  // [3]   P03 I/O port data
#define   GPIO_P0_P0D_P04D	   0x10 	  // [4]   P04 I/O port data
#define   GPIO_P0_P0D_P05D	   0x20 	  // [5]   P05 I/O port data
#define   GPIO_P0_P0D_P06D	   0x40 	  // [6]   P06 I/O port data
#define   GPIO_P0_P0D_P07D	   0x80 	  // [7]   P07 I/O port data

// P0 I/O control register
#define GPIO_P0_IOC0_ADDR	   ((volatile unsigned char*)0x00300381)
#define   GPIO_P0_IOC0_IOC00   0x01 	  // [0]   P00 I/O control
#define   GPIO_P0_IOC0_IOC01   0x02 	  // [1]   P01 I/O control
#define   GPIO_P0_IOC0_IOC02   0x04 	  // [2]   P02 I/O control
#define   GPIO_P0_IOC0_IOC03   0x08 	  // [3]   P03 I/O control
#define   GPIO_P0_IOC0_IOC04   0x10 	  // [4]   P04 I/O control
#define   GPIO_P0_IOC0_IOC05   0x20 	  // [5]   P05 I/O control
#define   GPIO_P0_IOC0_IOC06   0x40 	  // [6]   P06 I/O control
#define   GPIO_P0_IOC0_IOC07   0x80 	  // [7]   P07 I/O control

// P1 port data register
#define GPIO_P1_P1D_ADDR	   ((volatile unsigned char*)0x00300382)
#define   GPIO_P1_P1D_P10D	   0x01 	  // [0]   P10 I/O port data
#define   GPIO_P1_P1D_P11D	   0x02 	  // [1]   P11 I/O port data
#define   GPIO_P1_P1D_P12D	   0x04 	  // [2]   P12 I/O port data
#define   GPIO_P1_P1D_P13D	   0x08 	  // [3]   P13 I/O port data
#define   GPIO_P1_P1D_P14D	   0x10 	  // [4]   P14 I/O port data
#define   GPIO_P1_P1D_P15D	   0x20 	  // [5]   P15 I/O port data
#define   GPIO_P1_P1D_P16D	   0x40 	  // [6]   P16 I/O port data
#define   GPIO_P1_P1D_P17D	   0x80 	  // [7]   P17 I/O port data

// P1 I/O control register
#define GPIO_P1_IOC1_ADDR	   ((volatile unsigned char*)0x00300383)
#define   GPIO_P1_IOC1_IOC10   0x01 	  // [0]   P10 I/O control
#define   GPIO_P1_IOC1_IOC11   0x02 	  // [1]   P11 I/O control
#define   GPIO_P1_IOC1_IOC12   0x04 	  // [2]   P12 I/O control
#define   GPIO_P1_IOC1_IOC13   0x08 	  // [3]   P13 I/O control
#define   GPIO_P1_IOC1_IOC14   0x10 	  // [4]   P14 I/O control
#define   GPIO_P1_IOC1_IOC15   0x20 	  // [5]   P15 I/O control
#define   GPIO_P1_IOC1_IOC16   0x40 	  // [6]   P16 I/O control
#define   GPIO_P1_IOC1_IOC17   0x80 	  // [7]   P17 I/O control

// P2 port data register
#define GPIO_P2_P2D_ADDR	   ((volatile unsigned char*)0x00300384)
#define   GPIO_P2_P2D_P20D	   0x01 	  // [0]   P20 I/O port data
#define   GPIO_P2_P2D_P21D	   0x02 	  // [1]   P21 I/O port data
#define   GPIO_P2_P2D_P22D	   0x04 	  // [2]   P22 I/O port data
#define   GPIO_P2_P2D_P23D	   0x08 	  // [3]   P23 I/O port data
#define   GPIO_P2_P2D_P24D	   0x10 	  // [4]   P24 I/O port data
#define   GPIO_P2_P2D_P25D	   0x20 	  // [5]   P25 I/O port data
#define   GPIO_P2_P2D_P26D	   0x40 	  // [6]   P26 I/O port data
#define   GPIO_P2_P2D_P27D	   0x80 	  // [7]   P27 I/O port data

// P2 I/O control register
#define GPIO_P2_IOC2_ADDR	   ((volatile unsigned char*)0x00300385)
#define   GPIO_P2_IOC2_IOC20   0x01 	  // [0]   P20 I/O control
#define   GPIO_P2_IOC2_IOC21   0x02 	  // [1]   P21 I/O control
#define   GPIO_P2_IOC2_IOC22   0x04 	  // [2]   P22 I/O control
#define   GPIO_P2_IOC2_IOC23   0x08 	  // [3]   P23 I/O control
#define   GPIO_P2_IOC2_IOC24   0x10 	  // [4]   P24 I/O control
#define   GPIO_P2_IOC2_IOC25   0x20 	  // [5]   P25 I/O control
#define   GPIO_P2_IOC2_IOC26   0x40 	  // [6]   P26 I/O control
#define   GPIO_P2_IOC2_IOC27   0x80 	  // [7]   P27 I/O control

// P3 port data register
#define GPIO_P3_P3D_ADDR	   ((volatile unsigned char*)0x00300386)
#define   GPIO_P3_P3D_P30D	   0x01 	  // [0]   P30 I/O port data
#define   GPIO_P3_P3D_P31D	   0x02 	  // [1]   P31 I/O port data
#define   GPIO_P3_P3D_P32D	   0x04 	  // [2]   P32 I/O port data
#define   GPIO_P3_P3D_P33D	   0x08 	  // [3]   P33 I/O port data
#define   GPIO_P3_P3D_P34D	   0x10 	  // [4]   P34 I/O port data
#define   GPIO_P3_P3D_P35D	   0x20 	  // [5]   P35 I/O port data
#define   GPIO_P3_P3D_P36D	   0x40 	  // [6]   P36 I/O port data
#define   GPIO_P3_P3D_P37D	   0x80 	  // [7]   P37 I/O port data

// P3 I/O control register
#define GPIO_P3_IOC3_ADDR	   ((volatile unsigned char*)0x00300387)
#define   GPIO_P3_IOC3_IOC30   0x01 	  // [0]   P30 I/O control
#define   GPIO_P3_IOC3_IOC31   0x02 	  // [1]   P31 I/O control
#define   GPIO_P3_IOC3_IOC32   0x04 	  // [2]   P32 I/O control
#define   GPIO_P3_IOC3_IOC33   0x08 	  // [3]   P33 I/O control
#define   GPIO_P3_IOC3_IOC34   0x10 	  // [4]   P34 I/O control
#define   GPIO_P3_IOC3_IOC35   0x20 	  // [5]   P35 I/O control
#define   GPIO_P3_IOC3_IOC36   0x40 	  // [6]   P36 I/O control
#define   GPIO_P3_IOC3_IOC37   0x80 	  // [7]   P37 I/O control

// P4 port data register
#define GPIO_P4_P4D_ADDR	   ((volatile unsigned char*)0x00300388)
#define   GPIO_P4_P4D_P40D	   0x01 	  // [0]   P40 I/O port data
#define   GPIO_P4_P4D_P41D	   0x02 	  // [1]   P41 I/O port data
#define   GPIO_P4_P4D_P42D	   0x04 	  // [2]   P42 I/O port data
#define   GPIO_P4_P4D_P43D	   0x08 	  // [3]   P43 I/O port data
#define   GPIO_P4_P4D_P44D	   0x10 	  // [4]   P44 I/O port data
#define   GPIO_P4_P4D_P45D	   0x20 	  // [5]   P45 I/O port data
#define   GPIO_P4_P4D_P46D	   0x40 	  // [6]   P46 I/O port data
#define   GPIO_P4_P4D_P47D	   0x80 	  // [7]   P47 I/O port data

// P4 I/O control register
#define GPIO_P4_IOC4_ADDR	   ((volatile unsigned char*)0x00300389)
#define   GPIO_P4_IOC4_IOC40   0x01 	  // [0]   P40 I/O control
#define   GPIO_P4_IOC4_IOC41   0x02 	  // [1]   P41 I/O control
#define   GPIO_P4_IOC4_IOC42   0x04 	  // [2]   P42 I/O control
#define   GPIO_P4_IOC4_IOC43   0x08 	  // [3]   P43 I/O control
#define   GPIO_P4_IOC4_IOC44   0x10 	  // [4]   P44 I/O control
#define   GPIO_P4_IOC4_IOC45   0x20 	  // [5]   P45 I/O control
#define   GPIO_P4_IOC4_IOC46   0x40 	  // [6]   P46 I/O control
#define   GPIO_P4_IOC4_IOC47   0x80 	  // [7]   P47 I/O control

// P5 port data register
#define GPIO_P5_P5D_ADDR	   ((volatile unsigned char*)0x0030038a)
#define   GPIO_P5_P5D_P50D	   0x01 	  // [0]   P50 I/O port data
#define   GPIO_P5_P5D_P51D	   0x02 	  // [1]   P51 I/O port data
#define   GPIO_P5_P5D_P52D	   0x04 	  // [2]   P52 I/O port data
#define   GPIO_P5_P5D_P53D	   0x08 	  // [3]   P53 I/O port data
#define   GPIO_P5_P5D_P54D	   0x10 	  // [4]   P54 I/O port data
#define   GPIO_P5_P5D_P55D	   0x20 	  // [5]   P55 I/O port data
#define   GPIO_P5_P5D_P56D	   0x40 	  // [6]   P56 I/O port data
#define   GPIO_P5_P5D_P57D	   0x80 	  // [7]   P57 I/O port data

// P5 I/O control register
#define GPIO_P5_IOC5_ADDR	   ((volatile unsigned char*)0x0030038b)
#define   GPIO_P5_IOC5_IOC50   0x01 	  // [0]   P50 I/O control
#define   GPIO_P5_IOC5_IOC51   0x02 	  // [1]   P51 I/O control
#define   GPIO_P5_IOC5_IOC52   0x04 	  // [2]   P52 I/O control
#define   GPIO_P5_IOC5_IOC53   0x08 	  // [3]   P53 I/O control
#define   GPIO_P5_IOC5_IOC54   0x10 	  // [4]   P54 I/O control
#define   GPIO_P5_IOC5_IOC55   0x20 	  // [5]   P55 I/O control
#define   GPIO_P5_IOC5_IOC56   0x40 	  // [6]   P56 I/O control
#define   GPIO_P5_IOC5_IOC57   0x80 	  // [7]   P57 I/O control

// P6 port data register
#define GPIO_P6_P6D_ADDR	   ((volatile unsigned char*)0x0030038c)
#define   GPIO_P6_P6D_P60D	   0x01 	  // [0]   P60 I/O port data
#define   GPIO_P6_P6D_P61D	   0x02 	  // [1]   P61 I/O port data
#define   GPIO_P6_P6D_P62D	   0x04 	  // [2]   P62 I/O port data
#define   GPIO_P6_P6D_P63D	   0x08 	  // [3]   P63 I/O port data
#define   GPIO_P6_P6D_P64D	   0x10 	  // [4]   P64 I/O port data
#define   GPIO_P6_P6D_P65D	   0x20 	  // [5]   P65 I/O port data
#define   GPIO_P6_P6D_P66D	   0x40 	  // [6]   P66 I/O port data
#define   GPIO_P6_P6D_P67D	   0x80 	  // [7]   P67 I/O port data

// P6 I/O control register
#define GPIO_P6_IOC6_ADDR	   ((volatile unsigned char*)0x0030038d)
#define   GPIO_P6_IOC6_IOC60   0x01 	  // [0]   P60 I/O control
#define   GPIO_P6_IOC6_IOC61   0x02 	  // [1]   P61 I/O control
#define   GPIO_P6_IOC6_IOC62   0x04 	  // [2]   P62 I/O control
#define   GPIO_P6_IOC6_IOC63   0x08 	  // [3]   P63 I/O control
#define   GPIO_P6_IOC6_IOC64   0x10 	  // [4]   P64 I/O control
#define   GPIO_P6_IOC6_IOC65   0x20 	  // [5]   P65 I/O control
#define   GPIO_P6_IOC6_IOC66   0x40 	  // [6]   P66 I/O control
#define   GPIO_P6_IOC6_IOC67   0x80 	  // [7]   P67 I/O control

// P7 port data register
#define GPIO_P7_P7D_ADDR	   ((volatile unsigned char*)0x0030038e)
#define   GPIO_P7_P7D_P70D	   0x01 	  // [0]   P70 Input port data
#define   GPIO_P7_P7D_P71D	   0x02 	  // [1]   P71 Input port data
#define   GPIO_P7_P7D_P72D	   0x04 	  // [2]   P72 Input port data
#define   GPIO_P7_P7D_P73D	   0x08 	  // [3]   P73 Input port data
#define   GPIO_P7_P7D_P74D	   0x10 	  // [4]   P74 Input port data
										  // [7:5] reserved

// P8 port data register
#define GPIO_P8_P8D_ADDR	   ((volatile unsigned char*)0x00300390)
#define   GPIO_P8_P8D_P80D	   0x01 	  // [0]   P80 I/O port data
#define   GPIO_P8_P8D_P81D	   0x02 	  // [1]   P81 I/O port data
#define   GPIO_P8_P8D_P82D	   0x04 	  // [2]   P82 I/O port data
#define   GPIO_P8_P8D_P83D	   0x08 	  // [3]   P83 I/O port data
#define   GPIO_P8_P8D_P84D	   0x10 	  // [4]   P84 I/O port data
#define   GPIO_P8_P8D_P85D	   0x20 	  // [5]   P85 I/O port data
										  // [7:6] reserved

// P8 I/O control register
#define GPIO_P8_IOC8_ADDR	   ((volatile unsigned char*)0x00300391)
#define   GPIO_P8_IOC8_IOC80   0x01 	  // [0]   P80 I/O control
#define   GPIO_P8_IOC8_IOC81   0x02 	  // [1]   P81 I/O control
#define   GPIO_P8_IOC8_IOC82   0x04 	  // [2]   P82 I/O control
#define   GPIO_P8_IOC8_IOC83   0x08 	  // [3]   P83 I/O control
#define   GPIO_P8_IOC8_IOC84   0x10 	  // [4]   P84 I/O control
#define   GPIO_P8_IOC8_IOC85   0x20 	  // [5]   P85 I/O control
										  // [7:6] reserved

// P9 port data register
#define GPIO_P9_P9D_ADDR	   ((volatile unsigned char*)0x00300392)
#define   GPIO_P9_P9D_P90D	   0x01 	  // [0]   P90 I/O port data
#define   GPIO_P9_P9D_P91D	   0x02 	  // [1]   P91 I/O port data
#define   GPIO_P9_P9D_P92D	   0x04 	  // [2]   P92 I/O port data
#define   GPIO_P9_P9D_P93D	   0x08 	  // [3]   P93 I/O port data
#define   GPIO_P9_P9D_P94D	   0x10 	  // [4]   P94 I/O port data
#define   GPIO_P9_P9D_P95D	   0x20 	  // [5]   P95 I/O port data
#define   GPIO_P9_P9D_P96D	   0x40 	  // [6]   P96 I/O port data
#define   GPIO_P9_P9D_P97D	   0x80 	  // [7]   P97 I/O port data

// P9 I/O control register
#define GPIO_P9_IOC9_ADDR	   ((volatile unsigned char*)0x00300393)
#define   GPIO_P9_IOC9_IOC90   0x01 	  // [0]   P90 I/O control
#define   GPIO_P9_IOC9_IOC91   0x02 	  // [1]   P91 I/O control
#define   GPIO_P9_IOC9_IOC92   0x04 	  // [2]   P92 I/O control
#define   GPIO_P9_IOC9_IOC93   0x08 	  // [3]   P93 I/O control
#define   GPIO_P9_IOC9_IOC94   0x10 	  // [4]   P94 I/O control
#define   GPIO_P9_IOC9_IOC95   0x20 	  // [5]   P95 I/O control
#define   GPIO_P9_IOC9_IOC96   0x40 	  // [6]   P96 I/O control
#define   GPIO_P9_IOC9_IOC97   0x80 	  // [7]   P97 I/O control

// P00-P03 port function select register
#define GPIO_P0_03_CFP_ADDR    ((volatile unsigned char*)0x003003a0)
#define   GPIO_P0_03_CFP_CFP00 0x03 	  // [1:0] P00 port extended function
#define   GPIO_P0_03_CFP_CFP01 0x0c 	  // [3:2] P01 port extended function
#define   GPIO_P0_03_CFP_CFP02 0x30 	  // [5:4] P02 port extended function
#define   GPIO_P0_03_CFP_CFP03 0xc0 	  // [7:6] P03 port extended function

// P04-P07 port function select register
#define GPIO_P0_47_CFP_ADDR    ((volatile unsigned char*)0x003003a1)
#define   GPIO_P0_47_CFP_CFP04 0x03 	  // [1:0] P04 port extended function
#define   GPIO_P0_47_CFP_CFP05 0x0c 	  // [3:2] P05 port extended function
#define   GPIO_P0_47_CFP_CFP06 0x30 	  // [5:4] P06 port extended function
#define   GPIO_P0_47_CFP_CFP07 0xc0 	  // [7:6] P07 port extended function

// P10-P13 port function select register
#define GPIO_P1_03_CFP_ADDR    ((volatile unsigned char*)0x003003a2)
#define   GPIO_P1_03_CFP_CFP10 0x03 	  // [1:0] P10 port extended function
#define   GPIO_P1_03_CFP_CFP11 0x0c 	  // [3:2] P11 port extended function
#define   GPIO_P1_03_CFP_CFP12 0x30 	  // [5:4] P12 port extended function
#define   GPIO_P1_03_CFP_CFP13 0xc0 	  // [7:6] P13 port extended function

// P14-P17 port function select register
#define GPIO_P1_47_CFP_ADDR    ((volatile unsigned char*)0x003003a3)
#define   GPIO_P1_47_CFP_CFP14 0x03 	  // [1:0] P14 port extended function
#define   GPIO_P1_47_CFP_CFP15 0x0c 	  // [3:2] P15 port extended function
#define   GPIO_P1_47_CFP_CFP16 0x30 	  // [5:4] P16 port extended function
#define   GPIO_P1_47_CFP_CFP17 0xc0 	  // [7:6] P17 port extended function

// P20-P23 port function select register
#define GPIO_P2_03_CFP_ADDR    ((volatile unsigned char*)0x003003a4)
#define   GPIO_P2_03_CFP_CFP20 0x03 	  // [1:0] P20 port extended function
#define   GPIO_P2_03_CFP_CFP21 0x0c 	  // [3:2] P21 port extended function
#define   GPIO_P2_03_CFP_CFP22 0x30 	  // [5:4] P22 port extended function
#define   GPIO_P2_03_CFP_CFP23 0xc0 	  // [7:6] P23 port extended function

// P24-P27 port function select register
#define GPIO_P2_47_CFP_ADDR    ((volatile unsigned char*)0x003003a5)
#define   GPIO_P2_47_CFP_CFP24 0x03 	  // [1:0] P24 port extended function
#define   GPIO_P2_47_CFP_CFP25 0x0c 	  // [3:2] P25 port extended function
#define   GPIO_P2_47_CFP_CFP26 0x30 	  // [5:4] P26 port extended function
#define   GPIO_P2_47_CFP_CFP27 0xc0 	  // [7:6] P27 port extended function

// P30-P33 port function select register
#define GPIO_P3_03_CFP_ADDR    ((volatile unsigned char*)0x003003a6)
#define   GPIO_P3_03_CFP_CFP30 0x03 	  // [1:0] P30 port extended function
#define   GPIO_P3_03_CFP_CFP31 0x0c 	  // [3:2] P31 port extended function
#define   GPIO_P3_03_CFP_CFP32 0x30 	  // [5:4] P32 port extended function
#define   GPIO_P3_03_CFP_CFP33 0xc0 	  // [7:6] P33 port extended function

// P34-P37 port function select register
#define GPIO_P3_46_CFP_ADDR    ((volatile unsigned char*)0x003003a7)
#define   GPIO_P3_46_CFP_CFP34 0x03 	  // [1:0] P34 port extended function
#define   GPIO_P3_46_CFP_CFP35 0x0c 	  // [3:2] P35 port extended function
#define   GPIO_P3_46_CFP_CFP36 0x30 	  // [5:4] P36 port extended function
										  // [7:6] reserved

// P40-P43 port function select register
#define GPIO_P4_03_CFP_ADDR    ((volatile unsigned char*)0x003003a8)
#define   GPIO_P4_03_CFP_CFP40 0x03 	  // [1:0] P40 port extended function
#define   GPIO_P4_03_CFP_CFP41 0x0c 	  // [3:2] P41 port extended function
#define   GPIO_P4_03_CFP_CFP42 0x30 	  // [5:4] P42 port extended function
#define   GPIO_P4_03_CFP_CFP43 0xc0 	  // [7:6] P43 port extended function

// P44-P47 port function select register
#define GPIO_P4_47_CFP_ADDR    ((volatile unsigned char*)0x003003a9)
#define   GPIO_P4_47_CFP_CFP44 0x03 	  // [1:0] P44 port extended function
#define   GPIO_P4_47_CFP_CFP45 0x0c 	  // [3:2] P45 port extended function
#define   GPIO_P4_47_CFP_CFP46 0x30 	  // [5:4] P46 port extended function
#define   GPIO_P4_47_CFP_CFP47 0xc0 	  // [7:6] P47 port extended function

// P50-P53 port function select register
#define GPIO_P5_03_CFP_ADDR    ((volatile unsigned char*)0x003003aa)
#define   GPIO_P5_03_CFP_CFP50 0x03 	  // [1:0] P50 port extended function
#define   GPIO_P5_03_CFP_CFP51 0x0c 	  // [3:2] P51 port extended function
#define   GPIO_P5_03_CFP_CFP52 0x30 	  // [5:4] P52 port extended function
#define   GPIO_P5_03_CFP_CFP53 0xc0 	  // [7:6] P53 port extended function

// P54-P57 port function select register
#define GPIO_P5_47_CFP_ADDR    ((volatile unsigned char*)0x003003ab)
#define   GPIO_P5_47_CFP_CFP54 0x03 	  // [1:0] P54 port extended function
#define   GPIO_P5_47_CFP_CFP55 0x0c 	  // [3:2] P55 port extended function
#define   GPIO_P5_47_CFP_CFP56 0x30 	  // [5:4] P56 port extended function
#define   GPIO_P5_47_CFP_CFP57 0xc0 	  // [7:6] P57 port extended function

// P60-P63 port function select register
#define GPIO_P6_03_CFP_ADDR    ((volatile unsigned char*)0x003003ac)
#define   GPIO_P6_03_CFP_CFP60 0x03 	  // [1:0] P60 port extended function
#define   GPIO_P6_03_CFP_CFP61 0x0c 	  // [3:2] P61 port extended function
#define   GPIO_P6_03_CFP_CFP62 0x30 	  // [5:4] P62 port extended function
#define   GPIO_P6_03_CFP_CFP63 0xc0 	  // [7:6] P63 port extended function

// P64-P67 port function select register
#define GPIO_P6_47_CFP_ADDR    ((volatile unsigned char*)0x003003ad)
#define   GPIO_P6_47_CFP_CFP64 0x03 	  // [1:0] P64 port extended function
#define   GPIO_P6_47_CFP_CFP65 0x0c 	  // [3:2] P65 port extended function
#define   GPIO_P6_47_CFP_CFP66 0x30 	  // [5:4] P66 port extended function
#define   GPIO_P6_47_CFP_CFP67 0xc0 	  // [7:6] P67 port extended function

// P70-P73 port function select register
#define GPIO_P7_03_CFP_ADDR    ((volatile unsigned char*)0x003003ae)
#define   GPIO_P7_03_CFP_CFP70 0x03 	  // [1:0] P70 port extended function
#define   GPIO_P7_03_CFP_CFP71 0x0c 	  // [3:2] P71 port extended function
#define   GPIO_P7_03_CFP_CFP72 0x30 	  // [5:4] P72 port extended function
#define   GPIO_P7_03_CFP_CFP73 0xc0 	  // [7:6] P73 port extended function

// P74-P77 port function select register
#define GPIO_P7_4_CFP_ADDR	   ((volatile unsigned char*)0x003003af)
#define   GPIO_P7_4_CFP_CFP74  0x03 	  // [1:0] P74 port extended function
										  // [7:2] reserved

// P80-P83 port function select register
#define GPIO_P8_03_CFP_ADDR    ((volatile unsigned char*)0x003003b0)
#define   GPIO_P8_03_CFP_CFP80 0x03 	  // [1:0] P80 port extended function
#define   GPIO_P8_03_CFP_CFP81 0x0c 	  // [3:2] P81 port extended function
#define   GPIO_P8_03_CFP_CFP82 0x30 	  // [5:4] P82 port extended function
#define   GPIO_P8_03_CFP_CFP83 0xc0 	  // [7:6] P83 port extended function

// P84-P87 port function select register
#define GPIO_P8_45_CFP_ADDR    ((volatile unsigned char*)0x003003b1)
#define   GPIO_P8_45_CFP_CFP84 0x03 	  // [1:0] P84 port extended function
#define   GPIO_P8_45_CFP_CFP85 0x0c 	  // [3:2] P85 port extended function
										  // [7:4] reserved

// P90-P93 port function select register
#define GPIO_P9_03_CFP_ADDR    ((volatile unsigned char*)0x003003b2)
#define   GPIO_P9_03_CFP_CFP90 0x03 	  // [1:0] P90 port extended function
#define   GPIO_P9_03_CFP_CFP91 0x0c 	  // [3:2] P91 port extended function
#define   GPIO_P9_03_CFP_CFP92 0x30 	  // [5:4] P92 port extended function
#define   GPIO_P9_03_CFP_CFP93 0xc0 	  // [7:6] P93 port extended function

// P94-P97 port function select register
#define GPIO_P9_47_CFP_ADDR    ((volatile unsigned char*)0x003003b3)
#define   GPIO_P9_47_CFP_CFP94 0x03 	  // [1:0] P94 port extended function
#define   GPIO_P9_47_CFP_CFP95 0x0c 	  // [3:2] P95 port extended function
#define   GPIO_P9_47_CFP_CFP96 0x30 	  // [5:4] P96 port extended function
#define   GPIO_P9_47_CFP_CFP97 0xc0 	  // [7:6] P97 port extended function

// Port input interrupt select register 1
#define GPIO_PINTSEL_SPT03_ADDR   ((volatile unsigned char*)0x003003c0)
#define   GPIO_PINTSEL_SPT03_SPT0 0x03		 // [1:0] FPT0 interrupt input port selection
#define   GPIO_PINTSEL_SPT03_SPT1 0x0c		 // [3:2] FPT1 interrupt input port selection
#define   GPIO_PINTSEL_SPT03_SPT2 0x30		 // [5:4] FPT2 interrupt input port selection
#define   GPIO_PINTSEL_SPT03_SPT3 0xc0		 // [7:6] FPT3 interrupt input port selection

// Port input interrupt select register 2
#define GPIO_PINTSEL_SPT47_ADDR   ((volatile unsigned char*)0x003003c1)
#define   GPIO_PINTSEL_SPT47_SPT4 0x03		 // [1:0] FPT4 interrupt input port selection
#define   GPIO_PINTSEL_SPT47_SPT5 0x0c		 // [3:2] FPT5 interrupt input port selection
#define   GPIO_PINTSEL_SPT47_SPT6 0x30		 // [5:4] FPT6 interrupt input port selection
#define   GPIO_PINTSEL_SPT47_SPT7 0xc0		 // [7:6] FPT7 interrupt input port selection

// Port input interrupt polarity select register 1
#define GPIO_PINTPOL_SPP07_ADDR   ((volatile unsigned char*)0x003003c2)
#define   GPIO_PINTPOL_SPP07_SPPT0 0x01 	  // [0]   FPT0 input polarity selection
#define   GPIO_PINTPOL_SPP07_SPPT1 0x02 	  // [1]   FPT1 input polarity selection
#define   GPIO_PINTPOL_SPP07_SPPT2 0x04 	  // [2]   FPT2 input polarity selection
#define   GPIO_PINTPOL_SPP07_SPPT3 0x08 	  // [3]   FPT3 input polarity selection
#define   GPIO_PINTPOL_SPP07_SPPT4 0x10 	  // [4]   FPT4 input polarity selection
#define   GPIO_PINTPOL_SPP07_SPPT5 0x20 	  // [5]   FPT5 input polarity selection
#define   GPIO_PINTPOL_SPP07_SPPT6 0x40 	  // [6]   FPT6 input polarity selection
#define   GPIO_PINTPOL_SPP07_SPPT7 0x80 	  // [7]   FPT7 input polarity selection

// Port input interrupt edge/level select register 1
#define GPIO_PINTEL_SEPT07_ADDR   ((volatile unsigned char*)0x003003c3)
#define   GPIO_PINTEL_SEPT07_SEPT0 0x01 	  // [0]   FPT0 edge/level selection
#define   GPIO_PINTEL_SEPT07_SEPT1 0x02 	  // [1]   FPT1 edge/level selection
#define   GPIO_PINTEL_SEPT07_SEPT2 0x04 	  // [2]   FPT2 edge/level selection
#define   GPIO_PINTEL_SEPT07_SEPT3 0x08 	  // [3]   FPT3 edge/level selection
#define   GPIO_PINTEL_SEPT07_SEPT4 0x10 	  // [4]   FPT4 edge/level selection
#define   GPIO_PINTEL_SEPT07_SEPT5 0x20 	  // [5]   FPT5 edge/level selection
#define   GPIO_PINTEL_SEPT07_SEPT6 0x40 	  // [6]   FPT6 edge/level selection
#define   GPIO_PINTEL_SEPT07_SEPT7 0x80 	  // [7]   FPT7 edge/level selection

// Port input interrupt select register 3
#define GPIO_PINTSEL_SPT811_ADDR   ((volatile unsigned char*)0x003003c4)
#define   GPIO_PINTSEL_SPT811_SPT8 0x03 	  // [1:0] FPT8 interrupt input port selection
#define   GPIO_PINTSEL_SPT811_SPT9 0x0c 	  // [3:2] FPT9 interrupt input port selection
#define   GPIO_PINTSEL_SPT811_SPTA 0x30 	  // [5:4] FPT10 interrupt input port selection
#define   GPIO_PINTSEL_SPT811_SPTB 0xc0 	  // [7:6] FPT11 interrupt input port selection

// Port input interrupt select register 4
#define GPIO_PINTSEL_SPT1215_ADDR	((volatile unsigned char*)0x003003c5)
#define   GPIO_PINTSEL_SPT1215_SPTC 0x03	   // [1:0] FPT12 interrupt input port selection
#define   GPIO_PINTSEL_SPT1215_SPTD 0x0c	   // [3:2] FPT13 interrupt input port selection
#define   GPIO_PINTSEL_SPT1215_SPTE 0x30	   // [5:4] FPT14 interrupt input port selection
#define   GPIO_PINTSEL_SPT1215_SPTF 0xc0	   // [7:6] FPT15 interrupt input port selection

// Port input interrupt polarity select register 2
#define GPIO_PINTPOL_SPP815_ADDR   ((volatile unsigned char*)0x003003c6)
#define   GPIO_PINTPOL_SPP815_SPPT8 0x01	   // [0]	FPT8 input polarity selection
#define   GPIO_PINTPOL_SPP815_SPPT9 0x02	   // [1]	FPT9 input polarity selection
#define   GPIO_PINTPOL_SPP815_SPPTA 0x04	   // [2]	FPT10 input polarity selection
#define   GPIO_PINTPOL_SPP815_SPPTB 0x08	   // [3]	FPT11 input polarity selection
#define   GPIO_PINTPOL_SPP815_SPPTC 0x10	   // [4]	FPT12 input polarity selection
#define   GPIO_PINTPOL_SPP815_SPPTD 0x20	   // [5]	FPT13 input polarity selection
#define   GPIO_PINTPOL_SPP815_SPPTE 0x40	   // [6]	FPT14 input polarity selection
#define   GPIO_PINTPOL_SPP815_SPPTF 0x80	   // [7]	FPT15 input polarity selection

// Port input interrupt edge/level select register 2
#define GPIO_PINTEL_SEPT815_ADDR   ((volatile unsigned char*)0x003003c7)
#define   GPIO_PINTEL_SEPT815_SEPT8 0x01	   // [0]	FPT8 edge/level selection
#define   GPIO_PINTEL_SEPT815_SEPT9 0x02	   // [1]	FPT9 edge/level selection
#define   GPIO_PINTEL_SEPT815_SEPTA 0x04	   // [2]	FPT10 edge/level selection
#define   GPIO_PINTEL_SEPT815_SEPTB 0x08	   // [3]	FPT11 edge/level selection
#define   GPIO_PINTEL_SEPT815_SEPTC 0x10	   // [4]	FPT12 edge/level selection
#define   GPIO_PINTEL_SEPT815_SEPTD 0x20	   // [5]	FPT13 edge/level selection
#define   GPIO_PINTEL_SEPT815_SEPTE 0x40	   // [6]	FPT14 edge/level selection
#define   GPIO_PINTEL_SEPT815_SEPTF 0x80	   // [7]	FPT15 edge/level selection

// Key input interrupt select register
#define GPIO_KINTSEL_SPPK01_ADDR   ((volatile unsigned char*)0x003003d0)
#define   GPIO_KINTSEL_SPPK01_SPPK0 0x07	   // [2:0] FPK0 interrupt input port selection
										  // [3]   reserved
#define   GPIO_KINTSEL_SPPK01_SPPK1 0x70	   // [6:4] FPK1 interrupt input port selection
										  // [7]   reserved

// Key input interrupt (FPK0) input comparison register
#define GPIO_KINTCOMP_SCPK0_ADDR   ((volatile unsigned char*)0x003003d2)
#define   GPIO_KINTCOMP_SCPK0_SCPK00 0x01		// [0]	 FPK00 input comparison
#define   GPIO_KINTCOMP_SCPK0_SCPK01 0x02		// [1]	 FPK01 input comparison
#define   GPIO_KINTCOMP_SCPK0_SCPK02 0x04		// [2]	 FPK02 input comparison
#define   GPIO_KINTCOMP_SCPK0_SCPK03 0x08		// [3]	 FPK03 input comparison
#define   GPIO_KINTCOMP_SCPK0_SCPK04 0x10		// [4]	 FPK04 input comparison
										  // [7:6] reserved

// Key input interrupt (FPK1) input comparison register
#define GPIO_KINTCOMP_SCPK1_ADDR   ((volatile unsigned char*)0x003003d3)
#define   GPIO_KINTCOMP_SCPK1_SCPK10 0x01		// [0]	 FPK10 input comparison
#define   GPIO_KINTCOMP_SCPK1_SCPK11 0x02		// [1]	 FPK11 input comparison
#define   GPIO_KINTCOMP_SCPK1_SCPK12 0x04		// [2]	 FPK12 input comparison
#define   GPIO_KINTCOMP_SCPK1_SCPK13 0x08		// [3]	 FPK13 input comparison
										  // [7:5] reserved

// Key input interrupt (FPK0) input mask register
#define GPIO_KINTCOMP_SMPK0_ADDR   ((volatile unsigned char*)0x003003d4)
#define   GPIO_KINTCOMP_SMPK0_SMPK00 0x01		// [0]	 FPK00 input mask
#define   GPIO_KINTCOMP_SMPK0_SMPK01 0x02		// [1]	 FPK01 input mask
#define   GPIO_KINTCOMP_SMPK0_SMPK02 0x04		// [2]	 FPK02 input mask
#define   GPIO_KINTCOMP_SMPK0_SMPK03 0x08		// [3]	 FPK03 input mask
#define   GPIO_KINTCOMP_SMPK0_SMPK04 0x10		// [4]	 FPK04 input mask
										  // [7:6] reserved

// Key input interrupt (FPK1) input mask register
#define GPIO_KINTCOMP_SMPK1_ADDR   ((volatile unsigned char*)0x003003d5)
#define   GPIO_KINTCOMP_SMPK1_SMPK10 0x01		// [0]	 FPK10 input mask
#define   GPIO_KINTCOMP_SMPK1_SMPK11 0x02		// [1]	 FPK11 input mask
#define   GPIO_KINTCOMP_SMPK1_SMPK12 0x04		// [2]	 FPK12 input mask
#define   GPIO_KINTCOMP_SMPK1_SMPK13 0x08		// [3]	 FPK13 input mask
										  // [7:5] reserved

/*****************************************************************************
	IDMA	(0x301100)	  Intelligent DMA Controller
*****************************************************************************/

// IDMA base address low-order 16 bits
#define IDMA_BASE0_ADDR 	   ((volatile unsigned short*)0x00301100)

// IDMA base address high-order 16 bits
#define IDMA_BASE1_ADDR 	   ((volatile unsigned short*)0x00301102)

// IDMA start register
#define IDMA_START_ADDR 	   ((volatile unsigned char*)0x00301104)
#define   IDMA_START_DCHN	   0x7f 	  // [6:0] IDMA channel number
#define   IDMA_START_DSTART    0x80 	  // [7]   IDMA start

// IDMA enable register
#define IDMA_EN_ADDR		   ((volatile unsigned char*)0x00301105)
#define   IDMA_EN_IDMAEN	   0x01 	  // [0]   IDMA enable (for software trigger)
										  // [7:1] reserved

/*****************************************************************************
	HSDMA	(0x301120)	  High-Speed DMA  Controller
*****************************************************************************/

// HSDMA Ch.0 transfer counter register
#define HSDMA_HS0_CNT_ADDR	   ((volatile unsigned short*)0x00301120)
#define   HSDMA_HS0_CNT_BLKLEN0 0x00ff	   // [7:0]   Ch.0 block length
#define   HSDMA_HS0_CNT_TC0_L  0xff00	  // [15:8]  Ch.0 transfer counter[7:0]

// HSDMA Ch.0 control register
#define HSDMA_HS0_CTL_ADDR	   ((volatile unsigned short*)0x00301122)
#define   HSDMA_HS0_CTL_TC0_H  0x00ff	  // [7:0]	 Ch.0 transfer counter[15:8]
										  // [13:8] reserved
#define   HSDMA_HS0_CTL_D0DIR  0x4000	  // [14]	 D) Invalid
#define   HSDMA_HS0_CTL_DUALM0 0x8000	  // [15]	 Ch.0 address mode selection

// HSDMA Ch.0 low-order source address setup register
#define HSDMA_HS0_SADR0_ADDR   ((volatile unsigned short*)0x00301124)

// HSDMA Ch.0 high-order source address setup register
#define HSDMA_HS0_SADR1_ADDR   ((volatile unsigned short*)0x00301126)
#define   HSDMA_HS0_SADR1_S0ADRH 0x0fff 	// [11:0]  D) Ch.0 source address[27:16]
#define   HSDMA_HS0_SADR1_S0IN 0x3000	  // [13:12] D) Ch.0 source address control
#define   HSDMA_HS0_SADR1_DATSIZE0 0x4000	  // [14]	 Ch.0 transfer data size
										  // [15]  reserved

// HSDMA Ch.0 low-order destination address setup register
#define HSDMA_HS0_DADR0_ADDR   ((volatile unsigned short*)0x00301128)

// HSDMA Ch.0 high-order destination address setup register
#define HSDMA_HS0_DADR1_ADDR   ((volatile unsigned short*)0x0030112a)
#define   HSDMA_HS0_DADR1_D0ADRH 0x0fff 	// [11:0]  D) Ch.0 destination address[27:16]

// HSDMA Ch.0 enable register
#define HSDMA_HS0_EN_ADDR	   ((volatile unsigned short*)0x0030112c)
#define   HSDMA_HS0_EN_HS0_EN  0x0001	  // [0]	 Ch.0 enable
										  // [15:1] reserved

// HSDMA Ch.0 trigger flag register
#define HSDMA_HS0_TF_ADDR	   ((volatile unsigned short*)0x0030112e)
#define   HSDMA_HS0_TF_HS0_TF  0x0001	  // [0]	 Ch.0 trigger flag clear (writing)
										  // [15:1] reserved

// HSDMA Ch.1 transfer counter register
#define HSDMA_HS1_CNT_ADDR	   ((volatile unsigned short*)0x00301130)
#define   HSDMA_HS1_CNT_BLKLEN1 0x00ff	   // [7:0]   Ch.1 block length
#define   HSDMA_HS1_CNT_TC1_L  0xff00	  // [15:8]  Ch.1 transfer counter[7:0]

// HSDMA Ch.1 control register
#define HSDMA_HS1_CTL_ADDR	   ((volatile unsigned short*)0x00301132)
#define   HSDMA_HS1_CTL_TC1_H  0x00ff	  // [7:0]	 Ch.1 transfer counter[15:8]
										  // [13:8] reserved
#define   HSDMA_HS1_CTL_D1DIR  0x4000	  // [14]	 D) Invalid
#define   HSDMA_HS1_CTL_DUALM1 0x8000	  // [15]	 Ch.1 address mode selection

// HSDMA Ch.1 low-order source address setup register
#define HSDMA_HS1_SADR0_ADDR   ((volatile unsigned short*)0x00301134)

// HSDMA Ch.1 high-order source address setup register
#define HSDMA_HS1_SADR1_ADDR   ((volatile unsigned short*)0x00301136)
#define   HSDMA_HS1_SADR1_S1ADRH 0x0fff 	// [11:0]  D) Ch.1 source address[27:16]
#define   HSDMA_HS1_SADR1_S1IN 0x3000	  // [13:12] D) Ch.1 source address control
#define   HSDMA_HS1_SADR1_DATSIZE1 0x4000	  // [14]	 Ch.1 transfer data size
										  // [15]  reserved

// HSDMA Ch.1 low-order destination address setup register
#define HSDMA_HS1_DADR0_ADDR   ((volatile unsigned short*)0x00301138)

// HSDMA Ch.1 high-order destination address setup register
#define HSDMA_HS1_DADR1_ADDR   ((volatile unsigned short*)0x0030113a)
#define   HSDMA_HS1_DADR1_D1ADRH 0x0fff 	// [11:0]  D) Ch.1 destination address[27:16]

// HSDMA Ch.1 enable register
#define HSDMA_HS1_EN_ADDR	   ((volatile unsigned short*)0x0030113c)
#define   HSDMA_HS1_EN_HS1_EN  0x0001	  // [0]	 Ch.1 enable
										  // [15:1] reserved

// HSDMA Ch.1 trigger flag register
#define HSDMA_HS1_TF_ADDR	   ((volatile unsigned short*)0x0030113e)
#define   HSDMA_HS1_TF_HS1_TF  0x0001	  // [0]	 Ch.1 trigger flag clear (writing)
										  // [15:1] reserved

// HSDMA Ch.2 transfer counter register
#define HSDMA_HS2_CNT_ADDR	   ((volatile unsigned short*)0x00301140)
#define   HSDMA_HS2_CNT_BLKLEN2 0x00ff	   // [7:0]   Ch.2 block length
#define   HSDMA_HS2_CNT_TC2_L  0xff00	  // [15:8]  Ch.2 transfer counter[7:0]

// HSDMA Ch.2 control register
#define HSDMA_HS2_CTL_ADDR	   ((volatile unsigned short*)0x00301142)
#define   HSDMA_HS2_CTL_TC2_H  0x00ff	  // [7:0]	 Ch.2 transfer counter[15:8]
										  // [13:8] reserved
#define   HSDMA_HS2_CTL_D2DIR  0x4000	  // [14]	 D) Invalid
#define   HSDMA_HS2_CTL_DUALM2 0x8000	  // [15]	 Ch.2 address mode selection

// HSDMA Ch.2 low-order source address setup register
#define HSDMA_HS2_SADR0_ADDR   ((volatile unsigned short*)0x00301144)

// HSDMA Ch.2 high-order source address setup register
#define HSDMA_HS2_SADR1_ADDR   ((volatile unsigned short*)0x00301146)
#define   HSDMA_HS2_SADR1_S2ADRH 0x0fff 	// [11:0]  D) Ch.2 source address[27:16]
#define   HSDMA_HS2_SADR1_S2IN 0x3000	  // [13:12] D) Ch.2 source address control
#define   HSDMA_HS2_SADR1_DATSIZE2 0x4000	  // [14]	 Ch.2 transfer data size
										  // [15]  reserved

// HSDMA Ch.2 low-order destination address setup register
#define HSDMA_HS2_DADR0_ADDR   ((volatile unsigned short*)0x00301148)

// HSDMA Ch.2 high-order destination address setup register
#define HSDMA_HS2_DADR1_ADDR   ((volatile unsigned short*)0x0030114a)
#define   HSDMA_HS2_DADR1_D2ADRH 0x0fff 	// [11:0]  D) Ch.2 destination address[27:16]

// HSDMA Ch.2 enable register
#define HSDMA_HS2_EN_ADDR	   ((volatile unsigned short*)0x0030114c)
#define   HSDMA_HS2_EN_HS2_EN  0x0001	  // [0]	 Ch.2 enable
										  // [15:1] reserved

// HSDMA Ch.2 trigger flag register
#define HSDMA_HS2_TF_ADDR	   ((volatile unsigned short*)0x0030114e)
#define   HSDMA_HS2_TF_HS2_TF  0x0001	  // [0]	 Ch.2 trigger flag clear (writing)
										  // [15:1] reserved

// HSDMA Ch.3 transfer counter register
#define HSDMA_HS3_CNT_ADDR	   ((volatile unsigned short*)0x00301150)
#define   HSDMA_HS3_CNT_BLKLEN3 0x00ff	   // [7:0]   Ch.3 block length
#define   HSDMA_HS3_CNT_TC3_L  0xff00	  // [15:8]  Ch.3 transfer counter[7:0]

// HSDMA Ch.3 control register
#define HSDMA_HS3_CTL_ADDR	   ((volatile unsigned short*)0x00301152)
#define   HSDMA_HS3_CTL_TC3_H  0x00ff	  // [7:0]	 Ch.3 transfer counter[15:8]
										  // [13:8] reserved
#define   HSDMA_HS3_CTL_D3DIR  0x4000	  // [14]	 D) Invalid
#define   HSDMA_HS3_CTL_DUALM3 0x8000	  // [15]	 Ch.3 address mode selection

// HSDMA Ch.3 low-order source address setup register
#define HSDMA_HS3_SADR0_ADDR   ((volatile unsigned short*)0x00301154)

// HSDMA Ch.3 high-order source address setup register
#define HSDMA_HS3_SADR1_ADDR   ((volatile unsigned short*)0x00301156)
#define   HSDMA_HS3_SADR1_S3ADRH 0x0fff 	// [11:0]  D) Ch.3 source address[27:16]
#define   HSDMA_HS3_SADR1_S3IN 0x3000	  // [13:12] D) Ch.3 source address control
#define   HSDMA_HS3_SADR1_DATSIZE3 0x4000	  // [14]	 Ch.3 transfer data size
										  // [15]  reserved

// HSDMA Ch.3 low-order destination address setup register
#define HSDMA_HS3_DADR0_ADDR   ((volatile unsigned short*)0x00301158)

// HSDMA Ch.3 high-order destination address setup register
#define HSDMA_HS3_DADR1_ADDR   ((volatile unsigned short*)0x0030115a)
#define   HSDMA_HS3_DADR1_D3ADRH 0x0fff 	// [11:0]  D) Ch.3 destination address[27:16]

// HSDMA Ch.3 enable register
#define HSDMA_HS3_EN_ADDR	   ((volatile unsigned short*)0x0030115c)
#define   HSDMA_HS3_EN_HS3_EN  0x0001	  // [0]	 Ch.3 enable
										  // [15:1] reserved

// HSDMA Ch.3 trigger flag register
#define HSDMA_HS3_TF_ADDR	   ((volatile unsigned short*)0x0030115e)
#define   HSDMA_HS3_TF_HS3_TF  0x0001	  // [0]	 Ch.3 trigger flag clear (writing)
										  // [15:1] reserved

// HSDMA Ch.0 control register
#define HSDMA_HS0_ADVMODE_ADDR	 ((volatile unsigned short*)0x00301162)
										  // [3:1] reserved
										  // [15:6] reserved

// HSDMA Ch.0 low-order source address setup register
#define HSDMA_HS0_ADV_SADR0_ADDR   ((volatile unsigned short*)0x00301164)

// HSDMA Ch.0 high-order source address setup register
#define HSDMA_HS0_ADV_SADR1_ADDR   ((volatile unsigned short*)0x00301166)

// HSDMA Ch.0 low-order destination address setup register
#define HSDMA_HS0_ADV_DADR0_ADDR   ((volatile unsigned short*)0x00301168)

// HSDMA Ch.0 high-order destination address setup register
#define HSDMA_HS0_ADV_DADR1_ADDR   ((volatile unsigned short*)0x0030116a)

// HSDMA Ch.1 control register
#define HSDMA_HS1_ADVMODE_ADDR	 ((volatile unsigned short*)0x00301172)
										  // [3:1] reserved
										  // [15:6] reserved

// HSDMA Ch.1 low-order source address setup register
#define HSDMA_HS1_ADV_SADR0_ADDR   ((volatile unsigned short*)0x00301174)

// HSDMA Ch.1 high-order source address setup register
#define HSDMA_HS1_ADV_SADR1_ADDR   ((volatile unsigned short*)0x00301176)

// HSDMA Ch.1 low-order destination address setup register
#define HSDMA_HS1_ADV_DADR0_ADDR   ((volatile unsigned short*)0x00301178)

// HSDMA Ch.1 high-order destination address setup register
#define HSDMA_HS1_ADV_DADR1_ADDR   ((volatile unsigned short*)0x0030117a)

// HSDMA Ch.2 control register
#define HSDMA_HS2_ADVMODE_ADDR	 ((volatile unsigned short*)0x00301182)
										  // [3:1] reserved
										  // [15:6] reserved

// HSDMA Ch.2 low-order source address setup register
#define HSDMA_HS2_ADV_SADR0_ADDR   ((volatile unsigned short*)0x00301184)

// HSDMA Ch.2 high-order source address setup register
#define HSDMA_HS2_ADV_SADR1_ADDR   ((volatile unsigned short*)0x00301186)

// HSDMA Ch.2 low-order destination address setup register
#define HSDMA_HS2_ADV_DADR0_ADDR   ((volatile unsigned short*)0x00301188)

// HSDMA Ch.2 high-order destination address setup register
#define HSDMA_HS2_ADV_DADR1_ADDR   ((volatile unsigned short*)0x0030118a)

// HSDMA Ch.3 control register
#define HSDMA_HS3_ADVMODE_ADDR	 ((volatile unsigned short*)0x00301192)
										  // [3:1] reserved
										  // [15:6] reserved

// HSDMA Ch.3 low-order source address setup register
#define HSDMA_HS3_ADV_SADR0_ADDR   ((volatile unsigned short*)0x00301194)

// HSDMA Ch.3 high-order source address setup register
#define HSDMA_HS3_ADV_SADR1_ADDR   ((volatile unsigned short*)0x00301196)

// HSDMA Ch.3 low-order destination address setup register
#define HSDMA_HS3_ADV_DADR0_ADDR   ((volatile unsigned short*)0x00301198)

// HSDMA Ch.3 high-order destination address setup register
#define HSDMA_HS3_ADV_DADR1_ADDR   ((volatile unsigned short*)0x0030119a)

// HSDMA
#define HSDMA_HS_CNTLMODE_ADDR	 ((volatile unsigned short*)0x0030119c)
#define   HSDMA_HS_CNTLMODE_HSDMAADV 0x0001 	// [0]	   Standard mode/advanced mode select
										  // [15:1] reserved

// DMA sequential access time register
#define HSDMA_HS_ACCTIME_ADDR	((volatile unsigned short*)0x0030119e)
#define   HSDMA_HS_ACCTIME_DMAACCTIME 0x000f	 // [3:0]	IDMA and HSDMA sequential access time setup
										  // [15:4] reserved
/*****************************************************************************
	SRAMC	(0x301500)	  SRAM Controller
*****************************************************************************/

// BCLK and setup time control register
#define SRAMC_BCLK_SETUP_ADDR	((volatile unsigned long*)0x00301500)
#define   SRAMC_BCLK_SETUP_BCLK 0x00000001 // [0]	  BCLK divide control
#define   SRAMC_BCLK_SETUP_CE4STUP 0x00000002 // [1]	 #CE4 setup time
#define   SRAMC_BCLK_SETUP_CE11STUP 0x00000004 // [2]	  #CE11 setup time
										  // [3]   reserved
#define   SRAMC_BCLK_SETUP_CE9HOLD 0x00000070 // [6:4]	 #CE9 area output disable time
#define   SRAMC_BCLK_SETUP_CE9BCLK 0x00000080 // [7]	 #CE9 area BCLK divide control
										  // [31:8] reserved

// Wait control register
#define SRAMC_SWAIT_ADDR	   ((volatile unsigned long*)0x00301504)
#define   SRAMC_SWAIT_CE4WAIT  0x00000007 // [2:0]	 Number of #CE4 static wait cycles
										  // [3]   reserved
#define   SRAMC_SWAIT_CE5WAIT  0x00000070 // [6:4]	 Number of #CE5 static wait cycles
										  // [7]   reserved
#define   SRAMC_SWAIT_CE6WAIT  0x00000700 // [10:8]  Number of #CE6 static wait cycles
										  // [11]  reserved
#define   SRAMC_SWAIT_CE7WAIT  0x00007000 // [14:12] Number of #CE7 static wait cycles
										  // [15]  reserved
#define   SRAMC_SWAIT_CE8WAIT  0x00070000 // [18:16] Number of #CE8 static wait cycles
										  // [19]  reserved
#define   SRAMC_SWAIT_CE9WAIT  0x00700000 // [22:20] Number of #CE9 static wait cycles
										  // [23]  reserved
#define   SRAMC_SWAIT_CE10WAIT 0x07000000 // [26:24] Number of #CE10 static wait cycles
										  // [27]  reserved
#define   SRAMC_SWAIT_CE11WAIT 0x70000000 // [30:28] Number of #CE11 static wait cycles
										  // [31]  reserved

// Device size setup register
#define SRAMC_SLV_SIZE_ADDR    ((volatile unsigned long*)0x00301508)
#define   SRAMC_SLV_SIZE_CE4SIZE 0x00000003 // [1:0]   #CE4 device size
#define   SRAMC_SLV_SIZE_CE5SIZE 0x0000000c // [3:2]   #CE5 device size
#define   SRAMC_SLV_SIZE_CE6SIZE 0x00000030 // [5:4]   #CE6 device size
#define   SRAMC_SLV_SIZE_CE7SIZE 0x000000c0 // [7:6]   #CE7 device size
#define   SRAMC_SLV_SIZE_CE8SIZE 0x00000300 // [9:8]   #CE8 device size
#define   SRAMC_SLV_SIZE_CE9SIZE 0x00000c00 // [11:10] #CE9 device size
										  // [13:12] reserved
#define   SRAMC_SLV_SIZE_CE11SIZE 0x0000c000 // [15:14] #CE11 device size
										  // [31:16] reserved

// Device type setup register
#define SRAMC_A0_BSL_ADDR	   ((volatile unsigned long*)0x0030150c)
#define   SRAMC_A0_BSL_CE4TYPE 0x00000001 // [0]	 #CE4 device type
#define   SRAMC_A0_BSL_CE5TYPE 0x00000002 // [1]	 #CE5 device type
#define   SRAMC_A0_BSL_CE6TYPE 0x00000004 // [2]	 #CE6 device type
#define   SRAMC_A0_BSL_CE7TYPE 0x00000008 // [3]	 #CE7 device type
#define   SRAMC_A0_BSL_CE8TYPE 0x00000010 // [4]	 #CE8 device type
#define   SRAMC_A0_BSL_CE9TYPE 0x00000020 // [5]	 #CE9 device type
#define   SRAMC_A0_BSL_CE10TYPE 0x00000040 // [6]	  #CE10 device type
#define   SRAMC_A0_BSL_CE11TYPE 0x00000080 // [7]	  #CE11 device type
										  // [31:8] reserved

// Area location setup register
#define SRAMC_ALS_ADDR		   ((volatile unsigned long*)0x00301510)
#define   SRAMC_ALS_A6LOC	   0x00000001 // [0]	 Area 6 location setup
										  // [31:1] reserved

/*****************************************************************************
	SDRAMC	(0x301600)	  SDRAM Controller
*****************************************************************************/

// SDRAM initial register
#define SDRAMC_INI_ADDR 	   ((volatile unsigned long*)0x00301600)
#define   SDRAMC_INI_INIREF    0x00000001 // [0]	 REF command enable for init.
#define   SDRAMC_INI_INIPRE    0x00000002 // [1]	 PALL command enable for init.
#define   SDRAMC_INI_INIMRS    0x00000004 // [2]	 MRS command enable for init.
#define   SDRAMC_INI_SDEN	   0x00000008 // [3]	 SDRAM initialize flag
#define   SDRAMC_INI_SDON	   0x00000010 // [4]	 SDRAM controller enable
										  // [31:6] reserved

// SDRAM configuration register
#define SDRAMC_CTL_ADDR 	   ((volatile unsigned long*)0x00000000)
#define   SDRAMC_CTL_ADDRC	   0x00000007 // [2:0]	 SDRAM address configuration
										  // [3]   reserved
#define   SDRAMC_CTL_T80NS	   0x000000f0 // [7:4]	 Number of SDRAM t_RC, t_RFC and t_XSR cycles
#define   SDRAMC_CTL_T60NS	   0x00000700 // [10:8]  Number of SDRAM tRAS cycles
										  // [11]  reserved
#define   SDRAMC_CTL_T24NS	   0x00003000 // [13:12] Number of SDRAM t_RP and t_RCD cycles
										  // [31:14] reserved

// SDRAM refresh register
#define SDRAMC_REF_ADDR 	   ((volatile unsigned long*)0x00301608)
#define   SDRAMC_REF_AURCO	   0x00000fff // [11:0]  SDRAM auto-refresh counter
										  // [15:12] reserved
#define   SDRAMC_REF_SELCO	   0x007f0000 // [22:16] SDRAM self-refresh counter
#define   SDRAMC_REF_SELEN	   0x00800000 // [23]	 SDRAM self-refresh enable
#define   SDRAMC_REF_SCKON	   0x01000000 // [24]	 SDRAM clock during self-refresh
#define   SDRAMC_REF_SELDO	   0x02000000 // [25]	 SDRAM self-refresh status
										  // [31:26] reserved

// SDRAM application configuration register
#define SDRAMC_APP_ADDR 	   ((volatile unsigned long*)0x00301610)
#define   SDRAMC_APP_IQB	   0x00000001 // [0]	 Instruction queue buffer enable
#define   SDRAMC_APP_APPON	   0x00000002 // [1]	 SDAPP control
#define   SDRAMC_APP_CAS	   0x0000000c // [3:2]	 CAS latency setup
#define   SDRAMC_APP_INCR	   0x00000010 // [4]	 INCR transfer enable
#define   SDRAMC_APP_DBF	   0x00000008 // [3]	 Double frequency mode enable
										  // [30:6] reserved
#define   SDRAMC_APP_ARBON	   0x80000000 // [31]	 Arbiter enable

/*****************************************************************************
	SPI 	(0x301700)	  SPI Controller
*****************************************************************************/

// SPI receive data register
#define SPI_RXD_ADDR		   ((volatile unsigned long*)0x00301700)

// SPI transmit data register
#define SPI_TXD_ADDR		   ((volatile unsigned long*)0x00301704)

// SPI control register 1
#define SPI_CTL1_ADDR		   ((volatile unsigned long*)0x00301708)
#define   SPI_CTL1_ENA		   0x00000001 // [0]	 SPI enable
#define   SPI_CTL1_MODE 	   0x00000002 // [1]	 SPI mode selection
#define   SPI_CTL1_RXDE 	   0x00000004 // [2]	 Receive DMA enable
#define   SPI_CTL1_TXDE 	   0x00000008 // [3]	 Transmit DMA enable
#define   SPI_CTL1_MCBR 	   0x00000070 // [6:4]	 Master clock bit rate (in master mode only)
										  // [7]   reserved
#define   SPI_CTL1_CPOL 	   0x00000100 // [8]	 SPI_CLK polarity selection
#define   SPI_CTL1_CPHA 	   0x00000200 // [9]	 SPI_CLK phase selection
#define   SPI_CTL1_BPT		   0x00007c00 // [14:10] Number of data bits per transfer
										  // [31:15] reserved

// SPI control register 2
#define SPI_CTL2_ADDR		   ((volatile unsigned long*)0x0030170c)
										  // [0]   reserved
										  // [1]   reserved
										  // [2]   reserved
										  // [7:3] reserved
										  // [8]   reserved
										  // [9]   reserved
#define   SPI_CTL2_SS		   0x00000400 // [10]	 Slave select control
										  // [11]  reserved
										  // [31:12] reserved

// SPI wait register
#define SPI_WAIT_ADDR		   ((volatile unsigned long*)0x00301710)

// SPI status register
#define SPI_STAT_ADDR		   ((volatile unsigned long*)0x00301714)
										  // [1:0] reserved
#define   SPI_STAT_RDFF 	   0x00000004 // [2]	 Receive data full flag
#define   SPI_STAT_RDOF 	   0x00000008 // [3]	 Receive data overflow flag
#define   SPI_STAT_TDEF 	   0x00000010 // [4]	 Transmit data empty flag
										  // [5]   reserved
#define   SPI_STAT_BSYF 	   0x00000040 // [6]	 Transfer busy flag
										  // [31:7] reserved

// SPI interrupt control register
#define SPI_INT_ADDR		   ((volatile unsigned long*)0x00301718)
#define   SPI_INT_IRQE		   0x00000001 // [0]	 Interrupt request enable
#define   SPI_INT_MIRQ		   0x00000002 // [1]	 Manual IRQ set/clear
#define   SPI_INT_RFIE		   0x00000004 // [2]	 Receive data full interrupt enable
#define   SPI_INT_ROIE		   0x00000008 // [3]	 Receive overflow interrupt enable
#define   SPI_INT_TEIE		   0x00000010 // [4]	 Transmit data empty int. enable
										  // [5]   reserved
										  // [31:6] reserved

// SPI receive data mask register
#define SPI_RXMK_ADDR		   ((volatile unsigned long*)0x0030171c)
										  // [0]   reserved
#define   SPI_RXMK_RXME 	   0x00000002 // [1]	 Receive data mask enable
										  // [9:2] reserved
#define   SPI_RXMK_RXMASK	   0x00007c00 // [14:10] Bit mask for reading received data
										  // [31:15] reserved


/*****************************************************************************
	LCDC	(0x301a00)	  LCD Controller
*****************************************************************************/

// Frame interrupt register
#define LCDC_INT_ADDR		   ((volatile unsigned long*)0x00301a00)
#define   LCDC_INT_INTEN	   0x00000001 // [0]	 Frame interrupt enable
										  // [31:1] reserved

// Status and 1 Generated 0 Not generated power save configuration register
#define LCDC_PS_ADDR		   ((volatile unsigned long*)0x00301a04)
#define   LCDC_PS_PSAVE 	   0x00000003 // [1:0]	 Power save mode
										  // [6:2] reserved
#define   LCDC_PS_VNDPF 	   0x00000080 // [7]	 Vertical display status
										  // [30:8] reserved
#define   LCDC_PS_INTF		   0x80000000 // [31]	 Frame interrupt flag

// Horizontal display register
#define LCDC_HD_ADDR		   ((volatile unsigned long*)0x00301a10)
#define   LCDC_HD_HDPCNT	   0x0000007f // [6:0]	 Horizontal display period (HDP) setup
										  // [15:7] reserved
#define   LCDC_HD_HTCNT 	   0x007f0000 // [22:16] Horizontal total period (HT) setup
										  // [31:23] reserved

// Vertical display register
#define LCDC_VD_ADDR		   ((volatile unsigned long*)0x00301a14)
#define   LCDC_VD_VDPCNT	   0x000003ff // [9:0]	 Vertical display period (VDP) setup
										  // [15:10] reserved
#define   LCDC_VD_VTCNT 	   0x03ff0000 // [25:16] Vertical total period (VT) setup
										  // [31:26] reserved

// MOD rate register
#define LCDC_MR_ADDR		   ((volatile unsigned long*)0x00301a18)
#define   LCDC_MR_MOD		   0x0000003f // [5:0]	 LCD MOD rate
										  // [31:6] reserved

// Horizontal display start position register
#define LCDC_HDPS_ADDR		   ((volatile unsigned long*)0x00301a20)
#define   LCDC_HDPS_HDPSCNT    0x000003ff // [9:0]	 Horizontal display period start position for HR-TFT
										  // [31:10] reserved

// Vertical display start position register
#define LCDC_VDPS_ADDR		   ((volatile unsigned long*)0x00301a24)
#define   LCDC_VDPS_VDPSCNT    0x000003ff // [9:0]	 Vertical display period start position for HR-TFT

// FPLINE pulse setup register
#define LCDC_L_ADDR 		   ((volatile unsigned long*)0x00301a28)
#define   LCDC_L_FPLWD		   0x0000007f // [6:0]	 FPLINE pulse width
#define   LCDC_L_FPLPOL 	   0x00000080 // [7]	 FPLINE pulse polarity
										  // [15:8] reserved
#define   LCDC_L_FPLST		   0x03ff0000 // [25:16] FPLINE pulse start position
										  // [31:26] reserved

// FPFRAME pulse setup register
#define LCDC_F_ADDR 		   ((volatile unsigned long*)0x00301a2c)
#define   LCDC_F_FPFWD		   0x00000007 // [2:0]	 FPFRAME pulse width
										  // [6:3] reserved
#define   LCDC_F_FPFPOL 	   0x00000080 // [7]	 FPFRAME pulse polarity
										  // [15:8] reserved
#define   LCDC_F_FPFST		   0x03ff0000 // [25:16] FPFRAME pulse start position
										  // [31:26] reserved

// FPFRAME pulse offset register
#define LCDC_FO_ADDR		   ((volatile unsigned long*)0x00301a30)
#define   LCDC_FO_FPFSTO	   0x000003ff // [9:0]	 FPFRAME pulse start offset
										  // [15:10] reserved
#define   LCDC_FO_FPFSTPO	   0x03ff0000 // [25:16] FPFRAME pulse stop offset
										  // [31:26] reserved

// HR-TFT special output register
#define LCDC_TSO_ADDR		   ((volatile unsigned long*)0x00301a40)
#define   LCDC_TSO_CTLSWAP	   0x00000001 // [0]	 TFT_CTL0/TFT_CTL1 swap
#define   LCDC_TSO_FPSPOL	   0x00000002 // [1]	 FPSHIFT polarity
#define   LCDC_TSO_PRESET	   0x00000004 // [2]	 TFT_CTL0-2 preset enable
#define   LCDC_TSO_CTL1CTL	   0x00000008 // [3]	 TFT_CTL1 control
										  // [31:4] reserved

// TFT_CTL1 pulse register
#define LCDC_TC1_ADDR		   ((volatile unsigned long*)0x00301a44)
#define   LCDC_TC1_CTL1ST	   0x000003ff // [9:0]	 TFT_CTL1 pulse stop offset
										  // [15:10] reserved
#define   LCDC_TC1_CTL1STP	   0x03ff0000 // [25:16] TFT_CTL1 pulse stop offset
										  // [31:26] reserved

// TFT_CTL0 pulse register
#define LCDC_TC0_ADDR		   ((volatile unsigned long*)0x00301a48)
#define   LCDC_TC0_CTL0ST	   0x000003ff // [9:0]	 TFT_CTL0 pulse stop offset
										  // [15:10] reserved
#define   LCDC_TC0_CTL0STP	   0x03ff0000 // [25:16] TFT_CTL0 pulse stop offset
										  // [31:26] reserved

// TFT_CTL2 register
#define LCDC_TC2_ADDR		   ((volatile unsigned long*)0x00301a4c)
#define   LCDC_TC2_CTL2DLY	   0x000003ff // [9:0]	 TFT_CTL2 delay
										  // [31:10] reserved

// LCDC display mode register
#define LCDC_DMD_ADDR		   ((volatile unsigned long*)0x00301a60)
#define   LCDC_DMD_BPP		   0x00000007 // [2:0]	 Bit-per-pixel select
										  // [3]   reserved
#define   LCDC_DMD_LUTPASS	   0x00000010 // [4]	 LUT bypass mode
										  // [5]   reserved
#define   LCDC_DMD_DITHEN	   0x00000040 // [6]	 Dither mode enable
#define   LCDC_DMD_FRMRPT	   0x00000080 // [7]	 Frame repeat for EL panel
										  // [23:8] reserved
#define   LCDC_DMD_BLANK	   0x01000000 // [24]	 Display blank enable
#define   LCDC_DMD_SWINV	   0x02000000 // [25]	 Software video invert
#define   LCDC_DMD_DWD		   0x0c000000 // [27:26] LCD panel data width
										  // [28]  reserved
#define   LCDC_DMD_FPSMASK	   0x20000000 // [29]	 FPSHIFT mask enable
#define   LCDC_DMD_COLOR	   0x40000000 // [30]	 Color/mono selection
#define   LCDC_DMD_TFTSEL	   0x80000000 // [31]	 HR-TFT panel selection

// IRAM select register
#define LCDC_IRAM_ADDR		   ((volatile unsigned long*)0x00301a64)
#define   LCDC_IRAM_IRAM	   0x00000001 // [0]	 IRAM assignment

// Main window display start address register
#define LCDC_MADD_ADDR		   ((volatile unsigned long*)0x00301a70)

// Main window
#define LCDC_MLADD_ADDR 	   ((volatile unsigned long*)0x00301a74)
#define   LCDC_MLADD_MWLADR    0x000003ff // [9:0]	 Main window line address offset

// Sub-window display start address register
#define LCDC_SADD_ADDR		   ((volatile unsigned long*)0x00301a80)

// Sub-window start position register
#define LCDC_SSP_ADDR		   ((volatile unsigned long*)0x00301a88)
#define   LCDC_SSP_PIPXST	   0x000003ff // [9:0]	 Sub-window horizontal (X) start position
										  // [15:10] reserved
#define   LCDC_SSP_PIPYST	   0x03ff0000 // [25:16] Sub-window vertical (Y) start position
										  // [30:26] reserved
#define   LCDC_SSP_PIPEN	   0x80000000 // [31]	 PIP sub-window enable

// Sub-window end position register
#define LCDC_SEP_ADDR		   ((volatile unsigned long*)0x00301a8c)
#define   LCDC_SEP_PIPXEND	   0x000003ff // [9:0]	 Sub-window horizontal (X) end position
										  // [15:10] reserved
#define   LCDC_SEP_PIPYEND	   0x03ff0000 // [25:16] Sub-window vertical (Y) end position
										  // [31:26] reserved

// Look-up table data register 0
#define LCDC_LUT_03_ADDR	   ((volatile unsigned long*)0x00301aa0)
										  // [1:0] reserved
#define   LCDC_LUT_03_LUT0	   0x000000fc // [7:2]	 Look-up table entry 0 data
										  // [9:8] reserved
#define   LCDC_LUT_03_LUT1	   0x0000fc00 // [15:10] Look-up table entry 1 data
										  // [17:16] reserved
#define   LCDC_LUT_03_LUT2	   0x00fc0000 // [23:18] Look-up table entry 2 data
										  // [25:24] reserved
#define   LCDC_LUT_03_LUT3	   0x03ffffff // [31:26] Look-up table entry 3 data

// Look-up table data register 1
#define LCDC_LUT_47_ADDR	   ((volatile unsigned long*)0x00301aa4)
										  // [1:0] reserved
#define   LCDC_LUT_47_LUT4	   0x000000fc // [7:2]	 Look-up table entry 4 data
										  // [9:8] reserved
#define   LCDC_LUT_47_LUT5	   0x0000fc00 // [15:10] Look-up table entry 5 data
										  // [17:16] reserved
#define   LCDC_LUT_47_LUT6	   0x00fc0000 // [23:18] Look-up table entry 6 data
										  // [25:24] reserved
#define   LCDC_LUT_47_LUT7	   0x03ffffff // [31:26] Look-up table entry 7 data

// Look-up table data register 2
#define LCDC_LUT_8B_ADDR	   ((volatile unsigned long*)0x00301aa8)
										  // [1:0] reserved
#define   LCDC_LUT_8B_LUT8	   0x000000fc // [7:2]	 Look-up table entry 8 data
										  // [9:8] reserved
#define   LCDC_LUT_8B_LUT9	   0x0000fc00 // [15:10] Look-up table entry 9 data
										  // [17:16] reserved
#define   LCDC_LUT_8B_LUTA	   0x00fc0000 // [23:18] Look-up table entry A data
										  // [25:24] reserved
#define   LCDC_LUT_8B_LUTB	   0x03ffffff // [31:26] Look-up table entry B data

// Look-up table data register 3
#define LCDC_LUT_CF_ADDR	   ((volatile unsigned long*)0x00301aaf)
										  // [1:0] reserved
#define   LCDC_LUT_CF_LUTC	   0x000000fc // [7:2]	 Look-up table entry C data
										  // [9:8] reserved
#define   LCDC_LUT_CF_LUTD	   0x0000fc00 // [15:10] Look-up table entry D data
										  // [17:16] reserved
#define   LCDC_LUT_CF_LUTE	   0x00fc0000 // [23:18] Look-up table entry E data
										  // [25:24] reserved
#define   LCDC_LUT_CF_LUTF	   0x03ffffff // [31:26] Look-up table entry F data

/*****************************************************************************
	CMU 	(0x301b00)	  Clock Management Unit
*****************************************************************************/

// Gated clock control register 0
#define CMU_GATEDCLK0_ADDR	   ((volatile unsigned long*)0x00301b00)
#define   CMU_GATEDCLK0_LCDC_CKE 0x00000001 // [0]	   LCDC main clock control
#define   CMU_GATEDCLK0_LCDCSAPB_CKE 0x00000002 // [1]	   LCDC SAPB I/F clock control
#define   CMU_GATEDCLK0_LCDCAHBIF_CKE 0x00000004 // [2] 	LCDC AHB I/F clock control
#define   CMU_GATEDCLK0_DSTRAM_CKE 0x00000008 // [3]	 DST RAM clock control
#define   CMU_GATEDCLK0_SDSAPB_CKE 0x00000010 // [4]	 SDRAMC SAPB I/F clock control
#define   CMU_GATEDCLK0_SDAPLCDC_CKE 0x00000020 // [5]	   SDRAMC LCDC APP clock control
#define   CMU_GATEDCLK0_SDAPCPU_CKE 0x00000040 // [6]	  SDRAMC CPU APP clock control
#define   CMU_GATEDCLK0_SDAPCPU_HCKE 0x00000080 // [7]	   SDRAMC CPU APP clock control (HALT)
#define   CMU_GATEDCLK0_USB_CKE 0x00000100 // [8]	  USB IP 48 MHz clock control
#define   CMU_GATEDCLK0_USBSAPB_CKE 0x00000200 // [9]	  USB SAPB I/F clock control
										  // [31:10] reserved

// Gated clock control register 1
#define CMU_GATEDCLK1_ADDR	   ((volatile unsigned long*)0x00301b04)
#define   CMU_GATEDCLK1_RTCSAPB_CKE 0x00000001 // [0]	  RTC SAPB I/F clock control
#define   CMU_GATEDCLK1_DMA_CKE 0x00000002 // [1]	  DMAC clock control
#define   CMU_GATEDCLK1_ITC_CKE 0x00000004 // [2]	  ITC clock control
#define   CMU_GATEDCLK1_ADC_CKE 0x00000008 // [3]	  ADC clock control
#define   CMU_GATEDCLK1_CARD_CKE 0x00000010 // [4]	   CARD I/F clock control
#define   CMU_GATEDCLK1_EFSIOSAPB_CKE 0x00000020 // [5] 	EFSIO SAPB I/F clock control
#define   CMU_GATEDCLK1_SPI_CKE 0x00000040 // [6]	  SPI clock control
#define   CMU_GATEDCLK1_SRAMSAPB_CKE 0x00000080 // [7]	   SRAMC SAPB I/F clock control
#define   CMU_GATEDCLK1_GPIO_CKE 0x00000100 // [8]	   GPIO normal clock control
#define   CMU_GATEDCLK1_WDT_CKE 0x00000200 // [9]	  Watchdog timer clock control
#define   CMU_GATEDCLK1_DCSIO_CKE 0x00000400 // [10]	DCSIO clock control
#define   CMU_GATEDCLK1_I2S_CKE 0x00000800 // [11]	  I2S clock control
#define   CMU_GATEDCLK1_EGPIO_CKE 0x00001000 // [12]	EGPIO clock control
#define   CMU_GATEDCLK1_TM0_CKE 0x00002000 // [13]	  16-bit timer 0 clock control
#define   CMU_GATEDCLK1_TM1_CKE 0x00004000 // [14]	  16-bit timer 1 clock control
#define   CMU_GATEDCLK1_TM2_CKE 0x00008000 // [15]	  16-bit timer 2 clock control
#define   CMU_GATEDCLK1_TM3_CKE 0x00010000 // [16]	  16-bit timer 3 clock control
#define   CMU_GATEDCLK1_TM4_CKE 0x00020000 // [17]	  16-bit timer 4 clock control
#define   CMU_GATEDCLK1_TM5_CKE 0x00040000 // [18]	  16-bit timer 5 clock control
#define   CMU_GATEDCLK1_IVRAMARB_CKE 0x00080000 // [19]    IVRAM arbiter clock control
										  // [23:20] reserved
#define   CMU_GATEDCLK1_MISC_HCKE 0x01000000 // [24]	Misc clock control (HALT)
#define   CMU_GATEDCLK1_EFSIOBR_HCKE 0x02000000 // [25]    EFSIO baud rate clk control (HALT)
#define   CMU_GATEDCLK1_SRAMC_HCKE 0x04000000 // [26]	 SRAMC clock control (HALT)
#define   CMU_GATEDCLK1_GPIONSTP_HCKE 0x08000000 // [27]	GPIO no stop clock control (HALT)
#define   CMU_GATEDCLK1_LCDCAHB_HCKE 0x10000000 // [28]    LCDC_AHB bus clk control (HALT)
#define   CMU_GATEDCLK1_CPUAHB_HCKE 0x20000000 // [29]	  CPU_AHB bus clk control (HALT)
										  // [31:30] reserved

// System clock control register
#define CMU_CLKCNTL_ADDR	   ((volatile unsigned long*)0x00301b08)
#define   CMU_CLKCNTL_SOSC1    0x00000001 // [0]	 Low-speed oscillation (OSC1) On/Off
#define   CMU_CLKCNTL_SOSC3    0x00000002 // [1]	 High-speed oscillation (OSC3) On/Off
#define   CMU_CLKCNTL_OSCSEL   0x0000000c // [3:2]	 OSC clock selection
										  // [7:4] reserved
#define   CMU_CLKCNTL_OSC3DIV  0x00000700 // [10:8]  OSC3 clock divider selection reserved
										  // [11]  reserved
#define   CMU_CLKCNTL_MCLKDIV  0x00001000 // [12]	 MCLK clock divider selection reserved
										  // [15:13] reserved
#define   CMU_CLKCNTL_LCDCDIV  0x000f0000 // [19:16] LCDC clock divider selection reserved
#define   CMU_CLKCNTL_PLLINDIV 0x00f00000 // [23:20] PLL input clock source divider selection
#define   CMU_CLKCNTL_CMU_CLKSEL 0x1f000000 // [28:24] CMU_CLK output clock source selection
										  // [31:29] reserved

// PLL control register
#define CMU_PLL_ADDR		   ((volatile unsigned long*)0x00301b0c)
#define   CMU_PLL_PLLPOWR	   0x00000001 // [0]	 PLL on/off control
										  // [1]   reserved
#define   CMU_PLL_PLLV		   0x0000000c // [3:2]	 PLL V-divider setup
#define   CMU_PLL_PLLN		   0x000000f0 // [7:4]	 PLL multiplication rate setup
#define   CMU_PLL_PLLRS 	   0x00000f00 // [11:8]  PLL LPF resistance setup
#define   CMU_PLL_PLLVC 	   0x0000f000 // [15:12] PLL VCO Kv setup
#define   CMU_PLL_PLLCP 	   0x001f0000 // [20:16] PLL charge pump current setup
#define   CMU_PLL_PLLBYP	   0x00200000 // [21]	 PLL bypass mode setup
#define   CMU_PLL_PLLCS 	   0x00c00000 // [23:22] PLL LPF capacitance setup
										  // [31:24] reserved

// SSCG macro control register
#define CMU_SSCG_ADDR		   ((volatile unsigned long*)0x00301b10)
#define   CMU_SSCG_SSMCON	   0x00000001 // [0]	 SSCG macro On/Off
										  // [7:1] reserved
#define   CMU_SSCG_SSMCIDT	   0x00000f00 // [11:8]  SSCG macro maximum frequency change width setting
#define   CMU_SSCG_SSMCITM	   0x0000f000 // [15:12] SSCG macro interval timer (ITM) setting
										  // [31:16] reserved

// Clock option register
#define CMU_OPT_ADDR		   ((volatile unsigned long*)0x00301b14)
#define   CMU_OPT_WAKEUPWT	   0x00000001 // [0]	 Wakeup-wait function enable
										  // [1]   reserved
#define   CMU_OPT_TMHSP 	   0x00000004 // [2]	 Wait-timer high-speed mode
#define   CMU_OPT_OSC3OFF	   0x00000008 // [3]	 OSC3 disable during SLEEP
										  // [7:4] reserved
#define   CMU_OPT_OSCTM 	   0x0000ff00 // [15:8]  OSC oscillation stabilization-wait timer
										  // [31:16] reserved

// Clock control protect register
#define CMU_PROTECT_ADDR	   ((volatile unsigned long*)0x00301b24)
#define   CMU_PROTECT_CLGP	   0x000000ff // [7:0]	 Clock control register protect flag
										  // [31:8] reserved
