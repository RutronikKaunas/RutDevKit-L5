
Project RUTDevKit:
PCB dimensions 94.3x83.3mm.
4 Layers.
Thickness: 1.55 mm. FR4
Mask color : Blue.
Silkscreen color: White.
Finish: Immersion GOLD
