
#pragma once
#include <iostream>
#include <sensorsapi.h>
#include <sensors.h>
#pragma comment(lib,"sensorsapi.lib")
#pragma comment (lib, "ole32.lib")
#include < stdlib.h >

/*

CO2 400-1,000ppm:
Concentrations typical of occupied indoor spaces with good air exchange.

CO2 1,000-2,000ppm:
Complaints of drowsiness and poor air.

CO2 2,000-5,000 ppm:
Headaches, sleepiness and stagnant, stale, stuffy air. Poor concentration, loss of attention, increased heart rate and slight nausea may also be present.

*/

#define CO2LEVELMIN 1000
#define CO2LEVELMAX 2000

namespace RutCO2Monitor 
{

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Threading;

	ISensorManager* sensorManager = 0;
	ISensorCollection* sensorList = 0;
	ULONG sensorsCount = 0;
	ISensor* sensor = 0;
	BSTR name = 0;
	SensorState state;
	ISensorDataReport* sensorData = 0;
	IPortableDeviceKeyCollection* keyList = 0;
	ULONG keysCount = 0;
	PROPERTYKEY sensorDataKey;
	PROPVARIANT sensorDataValue;
	PROPVARIANT sensorProperty;
	unsigned int sensor_index;
	unsigned int sensor_datakey;
	HRESULT hr = 0;
	bool com_init = false;
	bool sensor_online = false;

	ILocationPermissions *permiss = 0;

	/// <summary>
	/// Summary for Demo
	/// </summary>
	public ref class Demo : public System::Windows::Forms::Form
	{

	public:
		Demo(void)
		{
			InitializeComponent();

			/*Clear Textboxes*/
			DebugOutputBox->Text = "";
			ValueBox->Text = "";
			DebugOutputBox->Refresh();
			ValueBox->Refresh();

			/*Allocate Sensor Manager */
			com_init = InitializeCOM();
			if (!com_init)
			{
				DebugOutputBox->ForeColor = Color::DarkRed;
				DebugOutputBox->Text = "Error. Application will not start.";
				DebugOutputBox->Refresh();
				return;
			}

			/*Start looking for the sensor*/
			PingSensor->Start();
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Demo()
		{
			if (components)
			{
				delete components;
			}
		}


	private: System::Windows::Forms::Timer^ PingSensor;
	private: System::Windows::Forms::Timer^ ReadSensor;
	private: System::Windows::Forms::DataVisualization::Charting::Chart^ chart;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Label^ ValueBox;
	private: System::Windows::Forms::Label^ DebugOutputBox;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::PictureBox^ pictureBox2;
	private: System::Windows::Forms::PictureBox^ pictureBox3;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::Label^ label10;
	private: System::Windows::Forms::Label^ label11;
	private: System::Windows::Forms::Label^ label12;
	private: System::Windows::Forms::Label^ label13;
	private: System::Windows::Forms::Label^ label14;
	private: System::Windows::Forms::Label^ label15;
	private: System::Windows::Forms::Label^ label16;
	private: System::Windows::Forms::Label^ label17;
	private: System::Windows::Forms::Label^ label18;
	private: System::Windows::Forms::PictureBox^ pictureBox4;





	private: System::ComponentModel::IContainer^ components;
	protected:

	protected:

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::Windows::Forms::DataVisualization::Charting::ChartArea^ chartArea1 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::Legend^ legend1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Legend());
			System::Windows::Forms::DataVisualization::Charting::Series^ series1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(Demo::typeid));
			this->PingSensor = (gcnew System::Windows::Forms::Timer(this->components));
			this->ReadSensor = (gcnew System::Windows::Forms::Timer(this->components));
			this->chart = (gcnew System::Windows::Forms::DataVisualization::Charting::Chart());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->ValueBox = (gcnew System::Windows::Forms::Label());
			this->DebugOutputBox = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox3 = (gcnew System::Windows::Forms::PictureBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->pictureBox4 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox4))->BeginInit();
			this->SuspendLayout();
			// 
			// PingSensor
			// 
			this->PingSensor->Interval = 1000;
			this->PingSensor->Tick += gcnew System::EventHandler(this, &Demo::PingSensor_Tick);
			// 
			// ReadSensor
			// 
			this->ReadSensor->Tick += gcnew System::EventHandler(this, &Demo::ReadSensor_Tick);
			// 
			// chart
			// 
			this->chart->BackColor = System::Drawing::Color::Black;
			chartArea1->AxisX->Enabled = System::Windows::Forms::DataVisualization::Charting::AxisEnabled::False;
			chartArea1->AxisY->Enabled = System::Windows::Forms::DataVisualization::Charting::AxisEnabled::False;
			chartArea1->AxisY->IsStartedFromZero = false;
			chartArea1->BackColor = System::Drawing::Color::Black;
			chartArea1->Name = L"ChartArea1";
			this->chart->ChartAreas->Add(chartArea1);
			legend1->Enabled = false;
			legend1->Name = L"Legend1";
			this->chart->Legends->Add(legend1);
			this->chart->Location = System::Drawing::Point(12, 79);
			this->chart->Name = L"chart";
			series1->BackGradientStyle = System::Windows::Forms::DataVisualization::Charting::GradientStyle::TopBottom;
			series1->BackSecondaryColor = System::Drawing::Color::Transparent;
			series1->BorderColor = System::Drawing::Color::SeaShell;
			series1->BorderWidth = 5;
			series1->ChartArea = L"ChartArea1";
			series1->ChartType = System::Windows::Forms::DataVisualization::Charting::SeriesChartType::Area;
			series1->Color = System::Drawing::Color::ForestGreen;
			series1->IsVisibleInLegend = false;
			series1->Legend = L"Legend1";
			series1->Name = L"CO2X";
			series1->ShadowColor = System::Drawing::Color::White;
			series1->ShadowOffset = 1;
			this->chart->Series->Add(series1);
			this->chart->Size = System::Drawing::Size(539, 215);
			this->chart->SuppressExceptions = true;
			this->chart->TabIndex = 3;
			this->chart->Text = L"gpegpedit";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 30, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(132)), static_cast<System::Int32>(static_cast<System::Byte>(175)),
				static_cast<System::Int32>(static_cast<System::Byte>(31)));
			this->label1->Location = System::Drawing::Point(277, 367);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(97, 46);
			this->label1->TabIndex = 4;
			this->label1->Text = L"ppm";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::Black;
			this->label2->Font = (gcnew System::Drawing::Font(L"Verdana", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(239)), static_cast<System::Int32>(static_cast<System::Byte>(151)),
				static_cast<System::Int32>(static_cast<System::Byte>(3)));
			this->label2->Location = System::Drawing::Point(42, 335);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(68, 18);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Status:";
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(580, 295);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(364, 66);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox1->TabIndex = 6;
			this->pictureBox1->TabStop = false;
			// 
			// ValueBox
			// 
			this->ValueBox->AutoSize = true;
			this->ValueBox->BackColor = System::Drawing::Color::Black;
			this->ValueBox->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 30, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->ValueBox->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(132)), static_cast<System::Int32>(static_cast<System::Byte>(175)),
				static_cast<System::Int32>(static_cast<System::Byte>(31)));
			this->ValueBox->Location = System::Drawing::Point(179, 367);
			this->ValueBox->Name = L"ValueBox";
			this->ValueBox->Size = System::Drawing::Size(85, 46);
			this->ValueBox->TabIndex = 7;
			this->ValueBox->Text = L"-----";
			// 
			// DebugOutputBox
			// 
			this->DebugOutputBox->AutoSize = true;
			this->DebugOutputBox->BackColor = System::Drawing::Color::Black;
			this->DebugOutputBox->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->DebugOutputBox->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(132)), static_cast<System::Int32>(static_cast<System::Byte>(175)),
				static_cast<System::Int32>(static_cast<System::Byte>(31)));
			this->DebugOutputBox->Location = System::Drawing::Point(119, 335);
			this->DebugOutputBox->Name = L"DebugOutputBox";
			this->DebugOutputBox->Size = System::Drawing::Size(0, 18);
			this->DebugOutputBox->TabIndex = 8;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::Color::Silver;
			this->label3->Location = System::Drawing::Point(252, 9);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(105, 31);
			this->label3->TabIndex = 9;
			this->label3->Text = L"CO2eq";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::Color::Silver;
			this->label4->Location = System::Drawing::Point(209, 49);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(179, 18);
			this->label4->TabIndex = 10;
			this->label4->Text = L"Concentration in [ppm]";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::Color::Silver;
			this->label5->Location = System::Drawing::Point(42, 297);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(209, 18);
			this->label5->TabIndex = 11;
			this->label5->Text = L"Carbon Dioxide equivalent.";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->ForeColor = System::Drawing::Color::Silver;
			this->label6->Location = System::Drawing::Point(42, 317);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(117, 18);
			this->label6->TabIndex = 12;
			this->label6->Text = L"Measured with";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->ForeColor = System::Drawing::Color::DeepSkyBlue;
			this->label7->Location = System::Drawing::Point(159, 317);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(137, 18);
			this->label7->TabIndex = 13;
			this->label7->Text = L"Sensirion SGP30";
			// 
			// pictureBox2
			// 
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(575, 367);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(120, 50);
			this->pictureBox2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox2->TabIndex = 14;
			this->pictureBox2->TabStop = false;
			// 
			// pictureBox3
			// 
			this->pictureBox3->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox3.Image")));
			this->pictureBox3->Location = System::Drawing::Point(715, 367);
			this->pictureBox3->Name = L"pictureBox3";
			this->pictureBox3->Size = System::Drawing::Size(103, 50);
			this->pictureBox3->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox3->TabIndex = 15;
			this->pictureBox3->TabStop = false;
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 20.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->ForeColor = System::Drawing::Color::Silver;
			this->label8->Location = System::Drawing::Point(572, 9);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(372, 31);
			this->label8->TabIndex = 16;
			this->label8->Text = L"RutCO2Warn Demonstrator";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->ForeColor = System::Drawing::Color::Silver;
			this->label9->Location = System::Drawing::Point(572, 58);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(367, 18);
			this->label9->TabIndex = 17;
			this->label9->Text = L"This demo shows how the RutDevKit-STM32L5 ";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label10->ForeColor = System::Drawing::Color::Silver;
			this->label10->Location = System::Drawing::Point(572, 76);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(307, 18);
			this->label10->TabIndex = 18;
			this->label10->Text = L"performs with the RutAdptBoard-Epson.";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label11->ForeColor = System::Drawing::Color::Silver;
			this->label11->Location = System::Drawing::Point(572, 105);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(335, 18);
			this->label11->TabIndex = 19;
			this->label11->Text = L"Data from Sensirion SGP30 Multi Pixel Gas";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label12->ForeColor = System::Drawing::Color::Silver;
			this->label12->Location = System::Drawing::Point(572, 123);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(329, 18);
			this->label12->TabIndex = 20;
			this->label12->Text = L"sensor is sent via USB-C to the PC where ";
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label13->ForeColor = System::Drawing::Color::Silver;
			this->label13->Location = System::Drawing::Point(572, 141);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(144, 18);
			this->label13->TabIndex = 21;
			this->label13->Text = L"values are shown.";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label14->ForeColor = System::Drawing::Color::Silver;
			this->label14->Location = System::Drawing::Point(572, 170);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(319, 18);
			this->label14->TabIndex = 22;
			this->label14->Text = L"Epson S1V3G340 IC will output a warning";
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label15->ForeColor = System::Drawing::Color::Silver;
			this->label15->Location = System::Drawing::Point(572, 188);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(309, 18);
			this->label15->TabIndex = 23;
			this->label15->Text = L"message if a critical value of more than ";
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label16->ForeColor = System::Drawing::Color::Silver;
			this->label16->Location = System::Drawing::Point(572, 206);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(169, 18);
			this->label16->TabIndex = 24;
			this->label16->Text = L"1000 ppm is reached.";
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label17->ForeColor = System::Drawing::Color::Silver;
			this->label17->Location = System::Drawing::Point(572, 239);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(333, 18);
			this->label17->TabIndex = 25;
			this->label17->Text = L"If a value of 2000 ppm is reached a warning";
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 11.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label18->ForeColor = System::Drawing::Color::Silver;
			this->label18->Location = System::Drawing::Point(572, 257);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(176, 18);
			this->label18->TabIndex = 26;
			this->label18->Text = L"of the danger will play.";
			// 
			// pictureBox4
			// 
			this->pictureBox4->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox4.Image")));
			this->pictureBox4->Location = System::Drawing::Point(839, 367);
			this->pictureBox4->Name = L"pictureBox4";
			this->pictureBox4->Size = System::Drawing::Size(100, 50);
			this->pictureBox4->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox4->TabIndex = 27;
			this->pictureBox4->TabStop = false;
			// 
			// Demo
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::Black;
			this->ClientSize = System::Drawing::Size(953, 424);
			this->Controls->Add(this->pictureBox4);
			this->Controls->Add(this->label18);
			this->Controls->Add(this->label17);
			this->Controls->Add(this->label16);
			this->Controls->Add(this->label15);
			this->Controls->Add(this->label14);
			this->Controls->Add(this->label13);
			this->Controls->Add(this->label12);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->label10);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->pictureBox3);
			this->Controls->Add(this->pictureBox2);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->DebugOutputBox);
			this->Controls->Add(this->ValueBox);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->chart);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::Fixed3D;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Margin = System::Windows::Forms::Padding(2);
			this->MaximizeBox = false;
			this->Name = L"Demo";
			this->Text = L"RutCO2Monitor";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->chart))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox4))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

#pragma region Sensor Manager Allocator
		bool InitializeCOM()
		{
			hr = CoCreateInstance(CLSID_SensorManager, 0, CLSCTX_ALL, __uuidof(ISensorManager), (void**)&sensorManager);
			if (hr != 0 || !sensorManager)
			{
				return false;
			}
			return true;
		}
#pragma endregion

#pragma region Sensor Detector
	private: System::Void PingSensor_Tick(System::Object^ sender, System::EventArgs^ e) 
	{
		/*Try to connect if not connected*/
		if (!sensor_online)
		{
			/*Blink message*/
			DebugOutputBox->Text = "";
			ValueBox->Text = "";
			DebugOutputBox->Refresh();
			ValueBox->Refresh();
			Sleep(500);
			DebugOutputBox->ForeColor = Color::Gold;
			DebugOutputBox->Text = "Awaiting Connection...";
			ValueBox->Text = "-----";
			DebugOutputBox->Refresh();

			/*Look for environmental sensors online */
			hr = sensorManager->GetSensorsByCategory(SENSOR_TYPE_ENVIRONMENTAL_TEMPERATURE, &sensorList);
			if (hr != 0 || !sensorList)
			{
				if (sensorList != NULL) { sensorList->Release(); };
				return;
			}

			/*Request permissions*/
			hr = sensorManager->RequestPermissions(0, sensorList, TRUE);
			if (hr != 0)
			{
				DebugOutputBox->ForeColor = Color::DarkRed;
				DebugOutputBox->Text = "Access Denied.";
				if (sensorList != NULL) { sensorList->Release(); };
				return;
			}

			/*Count the sensors in a list*/
			hr = sensorList->GetCount(&sensorsCount);
			if (hr != 0 || !sensorsCount)
			{
				DebugOutputBox->ForeColor = Color::DarkRed;
				DebugOutputBox->Text = "No Sensors Found.";
				DebugOutputBox->Refresh();
				if (sensorList != NULL) { sensorList->Release(); };
				return;
			}

			/*Check all environmental sensors online*/
			for (unsigned int sensor_index = 0; sensor_index < sensorsCount; sensor_index++)
			{
				hr = sensorList->GetAt(sensor_index, &sensor);
				if (!sensor)
					continue;

				hr = sensor->GetFriendlyName(&name);
				if (hr != 0 || !name)
				{
					continue;
				}

				/*Demo is based on HID sensor, skip the rest*/
				if (!_stricmp((const char*)name, "HID Sensor Class Device"))
				{
					continue;
				}

				hr = sensor->GetState(&state);
				if (hr != 0)
				{
					continue;
				}
				switch (state)
				{
				case SENSOR_STATE_READY || SENSOR_STATE_MIN:
					break;
				case SENSOR_STATE_NOT_AVAILABLE:
					break;
				case SENSOR_STATE_INITIALIZING:
					break;
				case SENSOR_STATE_ERROR:
					break;
				case SENSOR_STATE_ACCESS_DENIED:
					break;
				case SENSOR_STATE_NO_DATA:
					break;
				default:
					break;
				}

				if (state != SENSOR_STATE_READY && state != SENSOR_STATE_MIN) 
				{
					continue;
				}

				hr = sensor->GetData(&sensorData);
				if (hr != 0 || !sensorData)
				{
					continue;
				}

				hr = sensor->GetSupportedDataFields(&keyList);
				if (hr != 0 || !keyList)
				{
					continue;
				}

				/*Make sure we take only STMicroelectronics device*/
				hr = sensor->GetProperty(SENSOR_PROPERTY_MANUFACTURER, &sensorProperty);
				if (!_stricmp((const char*)sensorProperty.pwszVal, "STMicroelectronics"))
				{
					continue;
				}

				keyList->GetCount(&keysCount);
				if (hr != 0 || !keysCount)
				{
					continue;
				}

				/*Look for the environmental sensors online*/
				for (unsigned int sensor_datakey = 0; sensor_datakey < keysCount; sensor_datakey++)
				{
					keyList->GetAt(sensor_datakey, &sensorDataKey);

					if (sensorDataKey.fmtid != SENSOR_DATA_TYPE_ENVIRONMENTAL_GUID)
					{
						continue;
					}

					sensorData->GetSensorValue(sensorDataKey, &sensorDataValue);

					/*If sensor has correct data type, assume sensor is found*/
					if (sensorDataKey == SENSOR_DATA_TYPE_TEMPERATURE_CELSIUS)
					{
						/*Stop detcting, start reading*/
						DebugOutputBox->ForeColor = Color::ForestGreen;
						String^ str1 = gcnew String(sensorProperty.pwszVal);
						String^ str2 = gcnew String(name);
						DebugOutputBox->Text = "Online: "+ str1 + " " + str2;
						DebugOutputBox->Refresh();
						sensor_online = true;
						PingSensor->Stop();
						ReadSensor->Start();

						/*Release allocated memory*/
						if (sensorList != NULL) { sensorList->Release(); };
						if (keyList != NULL) { keyList->Release(); };
						if (sensorData != NULL) { sensorData->Release(); };
						if (sensorManager != NULL) { sensorManager->Release(); };
						if (sensor != NULL) { sensor->Release(); };
						return;
					}
					else
					{
						continue;
					}
				}
				if (keyList != NULL) { keyList->Release(); };
			}
			if (sensor != NULL) { sensor->Release(); };

		}

	}
#pragma endregion

#pragma region Sensor Data Reader/Display
	private: System::Void ReadSensor_Tick(System::Object^ sender, System::EventArgs^ e) 
	{
		if (sensor_online)
		{
			/*Allocate new sensor manager*/
			com_init = InitializeCOM();
			if (!com_init)
			{
				goto error_state;
			}

			/*Look for environmental sensors online */
			hr = sensorManager->GetSensorsByCategory(SENSOR_TYPE_ENVIRONMENTAL_TEMPERATURE, &sensorList);
			if (hr != 0 || !sensorList)
			{
				goto error_state;
			}

			/*Request permissions*/
			hr = sensorManager->RequestPermissions(0, sensorList, TRUE);
			if (hr != 0)
			{
				goto error_state;
			}

			/*Count the sensors in a list*/
			hr = sensorList->GetCount(&sensorsCount);
			if (hr != 0 || !sensorsCount)
			{
				goto error_state;
			}

			/*Check all environmental sensors online*/
			for (unsigned int sensor_index = 0; sensor_index < sensorsCount; sensor_index++)
			{
				hr = sensorList->GetAt(sensor_index, &sensor);
				if (!sensor)
					continue;

				hr = sensor->GetFriendlyName(&name);
				if (hr != 0 || !name)
				{
					continue;
				}

				/*Demo is based on HID sensor, skip the rest*/
				if (!_stricmp((const char*)name, "HID Sensor Class Device"))
				{
					continue;
				}

				hr = sensor->GetState(&state);
				if (hr != 0)
				{
					continue;
				}
				switch (state)
				{
				case SENSOR_STATE_READY || SENSOR_STATE_MIN:
					break;
				case SENSOR_STATE_NOT_AVAILABLE:
					break;
				case SENSOR_STATE_INITIALIZING:
					break;
				case SENSOR_STATE_ERROR:
					break;
				case SENSOR_STATE_ACCESS_DENIED:
					break;
				case SENSOR_STATE_NO_DATA:
					break;
				default:
					break;
				}

				if (state != SENSOR_STATE_READY && state != SENSOR_STATE_MIN)
				{
					continue;
				}

				hr = sensor->GetData(&sensorData);
				if (hr != 0 || !sensorData)
				{
					continue;
				}

				hr = sensor->GetSupportedDataFields(&keyList);
				if (hr != 0 || !keyList)
				{
					continue;
				}

				/*Make sure we take only STMicroelectronics device*/
				hr = sensor->GetProperty(SENSOR_PROPERTY_MANUFACTURER, &sensorProperty);
				if (!_stricmp((const char*)sensorProperty.pwszVal, "STMicroelectronics"))
				{
					continue;
				}

				keyList->GetCount(&keysCount);
				if (hr != 0 || !keysCount)
				{
					continue;
				}

				/*Check if environmental sensor has the data type needed*/
				for (unsigned int sensor_datakey = 0; sensor_datakey < keysCount; sensor_datakey++)
				{
					keyList->GetAt(sensor_datakey, &sensorDataKey);

					if (sensorDataKey.fmtid != SENSOR_DATA_TYPE_ENVIRONMENTAL_GUID)
					{
						continue;
					}

					sensorData->GetSensorValue(sensorDataKey, &sensorDataValue);

					/*Assume it is CO2 sensor with Temperature data type*/
					if (sensorDataKey == SENSOR_DATA_TYPE_TEMPERATURE_CELSIUS)
					{
						/*Get sensor data value*/
						sensorData->GetSensorValue(sensorDataKey, &sensorDataValue);
						ValueBox->Text = Convert::ToString((unsigned int)sensorDataValue.fltVal);
						ValueBox->Refresh();

						/*Free allocated objects*/
						if (keyList != NULL) { keyList->Release(); };
						if (sensorList != NULL) { sensorList->Release(); };
						if (sensorData != NULL) { sensorData->Release(); };
						if (sensorManager != NULL) { sensorManager->Release(); };
						if (sensor != NULL) { sensor->Release(); };

						/*Draw the chart*/
						if (chart->IsHandleCreated)
						{
							/*Chart setup*/
							chart->ChartAreas["ChartArea1"]->AxisY->Maximum = Double::NaN;
							chart->ChartAreas["ChartArea1"]->AxisY->Minimum = Double::NaN;
							chart->ChartAreas[0]->RecalculateAxesScale();
							chart->Series["CO2X"]->Points->Add((unsigned int)sensorDataValue.fltVal);

							/*CO2 Level Indication*/
							if ((unsigned int)sensorDataValue.fltVal < CO2LEVELMIN)
							{
								chart->Series["CO2X"]->Color = System::Drawing::Color::ForestGreen;
								ValueBox->ForeColor = Color::ForestGreen;
								label1->ForeColor = Color::ForestGreen;
							}
							else if (((unsigned int)sensorDataValue.fltVal >= CO2LEVELMIN) && ((unsigned int)sensorDataValue.fltVal < CO2LEVELMAX))
							{
								chart->Series["CO2X"]->Color = System::Drawing::Color::Gold;
								ValueBox->ForeColor = Color::Gold;
								label1->ForeColor = Color::Gold;
							}
							else
							{
								chart->Series["CO2X"]->Color = System::Drawing::Color::Red;
								ValueBox->ForeColor = Color::Red;
								label1->ForeColor = Color::Red;
							}

							/*Count points and place them on a chart*/
							if (chart->Series[0]->Points->Count == 100)
							{
								chart->Series[0]->Points->RemoveAt(0);
							}
						}

						return;
					}
					else
					{
						continue;
					}
				}
			}

			/*Error handler*/
		error_state:
			ReadSensor->Stop();
			PingSensor->Start();
			sensor_online = false;
			if (keyList != NULL) { keyList->Release(); };
			if (sensorList != NULL) { sensorList->Release(); };
			return;
		}
	}
};
#pragma endregion
}
